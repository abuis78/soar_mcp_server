"""
SOAR MCP Server — Configuration Manager

Loads and parses mcp.conf from the app's local/ (user overrides) or
default/ (bundled defaults) directory, following Splunk/SOAR config
precedence rules (local beats default).

Copyright 2026 Andreas Buis
"""

from __future__ import annotations

import configparser
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional, Set, Union

logger = logging.getLogger(__name__)

_CONFIG_FILENAME = "mcp.conf"
_MANIFEST_FILENAME = "soar_mcp_server.json"


def _manifest_app_version() -> str:
    """Return app_version from the manifest so the MCP server reports the real
    version to clients instead of a hardcoded, drift-prone literal (issue #48)."""
    try:
        import json as _json
        manifest = Path(__file__).parent / _MANIFEST_FILENAME
        with open(manifest, encoding="utf-8") as fh:
            return str(_json.load(fh).get("app_version") or "").strip() or "0.0.0"
    except Exception:
        return "0.0.0"


# ── Valid values ───────────────────────────────────────────────────────────────
_VALID_SEVERITIES = {"high", "medium", "low", "informational", ""}


def normalise_base_url(raw: object) -> str:
    """Return a trusted, scheme-qualified SOAR base URL without a trailing slash,
    or "" if it is not usable. Rejects non-http(s) schemes and URLs with embedded
    credentials (issue #93, contributed by @reisball). Strict on purpose: this is
    an admin-configured value, so it must be a full, clean URL."""
    if not isinstance(raw, str):
        return ""
    from urllib.parse import urlparse
    val = raw.strip().rstrip("/")
    if not val:
        return ""
    parsed = urlparse(val)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        logger.warning("[MCP Config] Ignoring invalid base_url '%s'.", val)
        return ""
    if parsed.username or parsed.password:
        logger.warning("[MCP Config] Ignoring base_url with embedded credentials.")
        return ""
    return val

# ── All known tool names ───────────────────────────────────────────────────────
ALL_TOOLS: list[str] = [
    # Read-only
    "list_cases",
    "get_case",
    "search_cases",
    "list_artifacts",
    "get_artifact",
    "list_case_notes",
    "list_playbooks",
    "get_playbook_run",
    "list_action_runs",
    "list_users",
    "get_soar_info",
    # Write (controlled)
    "add_case_note",
    "run_playbook",
    "update_case_status",
    "update_case_severity",
    "update_case_owner",
    "create_artifact",
    # Playbook-Discovery & Build (v1.6.0+)
    "list_apps",
    "list_assets",
    "get_action_schema",
    "export_playbook",
    "import_playbook",
    "create_container",
    "delete_container",
    # COA Visual Editor tools (v1.6.3+)
    "resolve_playbook_current_id",
    "get_playbook_identity_map",
    "get_playbook_coa_summary",
    "list_playbook_nodes",
    "list_playbook_edges",
    "check_saved_generated_python_drift",
    "check_datapath_selectability",
    "diff_playbook_versions",
    "verify_layout_only_change",
    "validate_playbook_bundle",
    "check_visual_editor_compat",
    # Write tools (v1.6.3+)
    "save_playbook_layout_only",
    # Client config helper (v1.8.0+)
    "generate_mcp_client_config",
    # Diagnostics (v1.9.0+)
    "diagnose_soar_mcp_environment",
    # Capability detection (v1.10.0+)
    "detect_soar_capabilities",
    # Visual playbook pre-edit audit (v1.11.0+)
    "audit_visual_playbook",
    # Custom Function discovery — read-only (v1.13.0+, #155)
    "list_custom_functions",
    "get_custom_function",
    "detect_custom_function_capabilities",
    # Custom Function draft write (v1.14.0+, #159) — deliberately NOT in
    # READ_ONLY_TOOLS: that is what makes them write tools (confirmation gate).
    "create_custom_function_draft",
    "update_custom_function_draft",
]

READ_ONLY_TOOLS: frozenset[str] = frozenset(
    [
        "list_cases",
        "get_case",
        "search_cases",
        "list_artifacts",
        "get_artifact",
        "list_case_notes",
        "list_playbooks",
        "get_playbook_run",
        "list_action_runs",
        "list_users",
        "get_soar_info",
        # Playbook-Discovery & Build read tools (v1.6.0+)
        "list_apps",
        "list_assets",
        "get_action_schema",
        "export_playbook",
        # COA Visual Editor read tools (v1.6.3+)
        "resolve_playbook_current_id",
        "get_playbook_identity_map",
        "get_playbook_coa_summary",
        "list_playbook_nodes",
        "list_playbook_edges",
        "check_saved_generated_python_drift",
        "check_datapath_selectability",
        "diff_playbook_versions",
        "verify_layout_only_change",
        "validate_playbook_bundle",
        "check_visual_editor_compat",
        # Client config helper (v1.8.0+)
        "generate_mcp_client_config",
        # Diagnostics (v1.9.0+)
        "diagnose_soar_mcp_environment",
        # Capability detection (v1.10.0+)
        "detect_soar_capabilities",
        # Visual playbook pre-edit audit (v1.11.0+)
        "audit_visual_playbook",
        # Custom Function discovery — read-only (v1.13.0+, #155)
        "list_custom_functions",
        "get_custom_function",
        "detect_custom_function_capabilities",
    ]
)


@dataclass
class McpServerConfig:
    """
    Resolved configuration for the SOAR MCP Server.

    Populated by McpConfigLoader.load() from the mcp.conf file.
    All fields have safe defaults that match the bundled default/mcp.conf.
    """

    # [server] section
    timeout: float = 60.0
    max_results: int = 50
    # Trusted admin-configured SOAR base URL (mcp.conf [server] base_url). Used by
    # the handler as a fallback when phantom.rest is unavailable (issue #93).
    base_url: str = ""
    ssl_verify: Union[bool, str] = True
    log_tool_calls: bool = True
    protocol_version: str = "2024-11-05"
    server_name: str = "splunk-soar-mcp-server"
    server_version: str = field(default_factory=_manifest_app_version)

    # [tools] section — set of enabled tool names
    enabled_tools: Set[str] = field(default_factory=lambda: set(READ_ONLY_TOOLS))

    # [safety] section
    advisory_disclaimer: bool = True
    allowed_labels: list[str] = field(default_factory=list)
    max_items_per_case: int = 20
    min_severity: str = ""
    # Extra gate for create_container — prevents accidental case creation in production
    enable_test_harness: bool = False
    # Two-step commit for write tools (issue #50). When true, write tools must be
    # called twice: the first call returns a confirm_token, the second (with the
    # same args + token) executes. Default off = backwards-compatible.
    require_confirmation: bool = False
    # Test-harness portability (issue #117). The default container label ("test")
    # is not valid on every SOAR install; make it configurable. delete_container
    # also treats a name starting with test_container_name_prefix as suite-owned.
    test_container_label: str = "test"
    test_container_name_prefix: str = "mcp_"
    # Policy layer (gated-autonomous run_playbook, issue #135). Opt-in. When true,
    # every run_playbook is evaluated by the policy guard (ALLOW / APPROVE_1CLICK /
    # APPROVE_2PERSON / DENY) before dispatch. Default off = backwards-compatible.
    policy_enabled: bool = False

    # Policy Manager connection (SPEC-MCP MCP-G03). policy_mode selects the
    # decision path for write tools:
    #   ""        (empty, default) -> today's path: the in-app policy layer gates
    #                                 run_playbook only, governed by policy_enabled
    #   "service"                  -> every write tool is decided by the external
    #                                 Policy Manager (/v1/decide), fail-closed
    #   anything else ("embedded" is reserved until the policy_core wheel exists)
    #                              -> invalid: every write tool is refused
    # The transition rule (empty = today's behaviour) is deliberate so existing
    # installations keep working after the upgrade (concept OQ-8).
    policy_mode: str = ""
    policy_service_url: str = ""
    policy_timeout_s: float = 5.0
    # mTLS material for the service mode: file PATHS only, never contents. The
    # files are read by the policy client, never by the config loader.
    policy_client_cert: str = ""
    policy_client_key: str = ""
    policy_ca: str = ""

    # Custom Function draft-write allowlist (#159). Repository (scm_id) values that
    # create/update_custom_function_draft may write to. EMPTY = no write allowed at
    # all — fail-safe by design: the S1 probe showed 'local' is scm_id 2 while
    # 'community' (Splunk's own, read-only content) is 1, so a wrong default would
    # silently target the wrong repository. Admins opt in per asset config.
    custom_function_write_scm_ids: list[int] = field(default_factory=list)

    # Agent read exceptions (SPEC-MCP, MCP-L02). Tokens with principal_type
    # "agent" get NO direct read tools (they must read via the Tool Broker).
    # This explicit, admin-justified list names read tools an agent token may
    # still call directly. Default EMPTY = no exceptions. Only names from
    # READ_ONLY_TOOLS are accepted; anything else is dropped (fail-safe).
    agent_read_exceptions: list[str] = field(default_factory=list)

    # AI instructions — sent to the LLM in every MCP initialize response
    ai_instructions: str = ""

    # MCP endpoint URL (persisted from asset_overrides.json after first connect)
    mcp_endpoint: str = ""

    # ── Scoped MCP token settings (v1.5.0+) ───────────────────────────────
    # When enabled, incoming auth headers are first checked against the
    # app's local token store; matching scoped tokens get tool restrictions
    # and per-token audit. Legacy full-access SOAR ph-auth-token continues
    # to work as a fallback unless scoped_tokens_required is also True.
    scoped_tokens_enabled: bool = False  # opt-in; see default/mcp.conf [tokens]
    scoped_tokens_required: bool = False
    legacy_full_token_warn: bool = True
    # Default lifetime for newly minted tokens (days)
    token_default_lifetime_days: int = 90
    # Per-token rate limit (requests per minute). 0 disables.
    token_rate_limit_per_minute: int = 120

    @property
    def disabled_tools(self) -> list[str]:
        return [t for t in ALL_TOOLS if t not in self.enabled_tools]

    @property
    def write_tools_enabled(self) -> bool:
        return bool(self.enabled_tools - READ_ONLY_TOOLS)

    def to_summary_dict(self) -> dict:
        """Return a safe, serialisable summary (no secrets)."""
        return {
            "enabled_tools": sorted(self.enabled_tools),
            "disabled_tools": sorted(self.disabled_tools),
            "max_results": self.max_results,
            "max_items_per_case": self.max_items_per_case,
            "write_tools_enabled": self.write_tools_enabled,
            "agent_read_exceptions": sorted(self.agent_read_exceptions),
            "policy_mode": policy_effective_mode(self),
            "policy_service_url_configured": bool(self.policy_service_url),
            "advisory_disclaimer": self.advisory_disclaimer,
            "log_tool_calls": self.log_tool_calls,
            "protocol_version": self.protocol_version,
            "server_name": self.server_name,
            "server_version": self.server_version,
            "base_url_configured": bool(self.base_url),
            "ssl_verify": self.ssl_verify if isinstance(self.ssl_verify, bool) else "custom_path",
            "allowed_labels": self.allowed_labels,
            "min_severity": self.min_severity,
            "ai_instructions": self.ai_instructions,
        }


# Effective policy modes (SPEC-MCP MCP-G03 + concept OQ-8 transition rule).
POLICY_MODE_LEGACY = "legacy"    # policy_mode empty: in-app layer, run_playbook only
POLICY_MODE_SERVICE = "service"  # external Policy Manager decides every write tool
POLICY_MODE_INVALID = "invalid"  # unknown/reserved value or service without URL
POLICY_TIMEOUT_DEFAULT_S = 5.0
POLICY_TIMEOUT_MIN_S = 0.5
POLICY_TIMEOUT_MAX_S = 120.0


def policy_effective_mode(config: "McpServerConfig") -> str:
    """Translate the configured policy_mode into the effective mode.

    "" -> legacy (today's behaviour), "service" with a URL -> service, anything
    else -> invalid. Callers treat invalid as fail-closed for write tools; this
    helper itself never raises so a bad value can never crash the server.
    """
    raw = str(getattr(config, "policy_mode", "") or "").strip().lower()
    if raw == "":
        return POLICY_MODE_LEGACY
    if raw == POLICY_MODE_SERVICE:
        url = str(getattr(config, "policy_service_url", "") or "").strip()
        return POLICY_MODE_SERVICE if url else POLICY_MODE_INVALID
    return POLICY_MODE_INVALID


def build_posture_report(config: "McpServerConfig") -> dict:
    """Return the effective security posture of this asset (issue #51).

    Shared by Test Connectivity (#51) and the diagnostics tool (#67) so both
    surfaces report identical, non-secret state. Contains no tokens or secrets.
    """
    try:
        from soar_mcp_tokens import _have_fernet
        fernet_available = bool(_have_fernet())
    except Exception:
        fernet_available = False

    # #128: the legacy-path rate limiter is only active when the token store's
    # _RateLimiter is importable AND a positive limit is configured — mirror the
    # handler's actual condition, don't report the config value alone.
    try:
        from soar_mcp_tokens import _RateLimiter  # noqa: F401
        _rate_limiter_available = True
    except Exception:
        _rate_limiter_available = False

    enabled_write = sorted(config.enabled_tools - READ_ONLY_TOOLS)
    ssl = config.ssl_verify if isinstance(config.ssl_verify, bool) else "custom_path"

    # Coarse risk flags for a quick red/yellow/green read — advisory only.
    risk_flags: list[str] = []
    if enabled_write and ssl is False:
        risk_flags.append("write_tools_enabled_with_ssl_verify_off")
    if config.enable_test_harness:
        risk_flags.append("test_harness_enabled")
    if enabled_write and not config.require_confirmation:
        risk_flags.append("write_tools_without_confirmation")
    if config.scoped_tokens_enabled and not fernet_available:
        risk_flags.append("scoped_tokens_without_fernet_encryption")
    if config.scoped_tokens_enabled and not config.scoped_tokens_required and enabled_write:
        risk_flags.append("legacy_full_tokens_still_accepted")
    # run_playbook executes response actions; without the policy gate every run is
    # autonomous. Flag ungated execution so the posture reflects it (#151).
    if "run_playbook" in config.enabled_tools and not config.policy_enabled:
        risk_flags.append("run_playbook_without_policy_gate")
    # SPEC-MCP MCP-L02: every agent read exception widens the agent's direct
    # SOAR access past the Tool Broker — surface it so it is a conscious choice.
    agent_read_exceptions = sorted(getattr(config, "agent_read_exceptions", []) or [])
    if agent_read_exceptions:
        risk_flags.append("agent_read_exceptions_set")
    # SPEC-MCP MCP-G03: an unusable policy_mode refuses every write tool
    # (fail-closed). Surface it so the operator sees why writes are blocked.
    effective_policy_mode = policy_effective_mode(config)
    if effective_policy_mode == POLICY_MODE_INVALID:
        risk_flags.append("policy_mode_invalid")
    policy_mtls_configured = bool(
        config.policy_client_cert and config.policy_client_key and config.policy_ca)

    return {
        "write_tools_enabled": config.write_tools_enabled,
        "enabled_write_tools": enabled_write,
        "ssl_verify": ssl,
        "enable_test_harness": config.enable_test_harness,
        "require_confirmation": config.require_confirmation,
        "policy_enabled": config.policy_enabled,
        "policy_mode": effective_policy_mode,
        "policy_service_url_configured": bool(config.policy_service_url),
        "policy_mtls_configured": policy_mtls_configured,
        "agent_read_exceptions": agent_read_exceptions,
        "scoped_tokens_enabled": config.scoped_tokens_enabled,
        "scoped_tokens_required": config.scoped_tokens_required,
        "fernet_available": fernet_available,
        "legacy_path_rate_limited": bool(
            _rate_limiter_available and config.token_rate_limit_per_minute > 0),
        "advisory_disclaimer": config.advisory_disclaimer,
        "risk_flags": risk_flags,
    }


class McpConfigLoader:
    """
    Loads and parses mcp.conf following Splunk/SOAR config precedence.

    Search order:
      1. <app_root>/local/mcp.conf   (user overrides — highest precedence)
      2. <app_root>/default/mcp.conf (bundled defaults — fallback)

    The app root is determined relative to this module's location.
    """

    def __init__(self, app_root: Optional[Path] = None) -> None:
        if app_root is None:
            # This file lives at <app_root>/soar_mcp_config.py
            app_root = Path(__file__).parent
        self._app_root = app_root

    def _find_config_file(self) -> Optional[Path]:
        """Return the highest-precedence mcp.conf path, or None if not found."""
        for subdir in ("local", "default"):
            candidate = self._app_root / subdir / _CONFIG_FILENAME
            if candidate.exists():
                logger.info("[MCP Config] Found config at: %s", candidate)
                return candidate
        logger.warning("[MCP Config] No mcp.conf found in local/ or default/")
        return None

    def load(self) -> McpServerConfig:
        """
        Load and parse mcp.conf, returning a McpServerConfig with resolved values.

        Falls back to safe defaults for any missing or invalid values.
        Never raises; always returns a valid config object.
        """
        config = McpServerConfig()
        conf_path = self._find_config_file()

        if conf_path is None:
            logger.warning("[MCP Config] Using all defaults (no config file found).")
            return config

        parser = configparser.ConfigParser()
        try:
            parser.read(conf_path, encoding="utf-8")
        except Exception as exc:
            logger.error("[MCP Config] Failed to read %s: %s — using defaults.", conf_path, exc)
            return config

        # ── [server] ──────────────────────────────────────────────────────────
        config.timeout = self._get_float(parser, "server", "timeout", 60.0, min_val=1.0, max_val=300.0)
        config.max_results = self._get_int(parser, "server", "max_results", 50, min_val=1, max_val=500)
        config.base_url = normalise_base_url(
            parser.get("server", "base_url", fallback="").strip()
            or parser.get("server", "soar_base_url", fallback="").strip()
        )
        config.ssl_verify = self._parse_ssl_verify(parser.get("server", "ssl_verify", fallback="true"))
        config.log_tool_calls = self._get_bool(parser, "server", "log_tool_calls", True)
        config.protocol_version = parser.get("server", "protocol_version", fallback="2024-11-05").strip()
        config.server_name = parser.get("server", "server_name", fallback="splunk-soar-mcp-server").strip()
        config.server_version = parser.get(
            "server", "server_version", fallback=_manifest_app_version()
        ).strip() or _manifest_app_version()

        # ── [tools] ───────────────────────────────────────────────────────────
        enabled: set[str] = set()
        for tool in ALL_TOOLS:
            if self._get_bool(parser, "tools", tool, tool in READ_ONLY_TOOLS):
                enabled.add(tool)
        config.enabled_tools = enabled

        # ── [safety] ──────────────────────────────────────────────────────────
        config.advisory_disclaimer = self._get_bool(parser, "safety", "advisory_disclaimer", True)
        config.max_items_per_case = self._get_int(parser, "safety", "max_items_per_case", 20, min_val=1, max_val=200)

        raw_labels = parser.get("safety", "allowed_labels", fallback="").strip()
        config.allowed_labels = [lbl.strip() for lbl in raw_labels.split(",") if lbl.strip()] if raw_labels else []

        raw_sev = parser.get("safety", "min_severity", fallback="").strip().lower()
        config.min_severity = raw_sev if raw_sev in _VALID_SEVERITIES else ""
        config.enable_test_harness = self._get_bool(parser, "safety", "enable_test_harness", False)
        config.require_confirmation = self._get_bool(parser, "safety", "require_confirmation", False)
        config.policy_enabled = self._get_bool(parser, "policy", "enabled", False)
        config.policy_mode = parser.get("policy", "mode", fallback="").strip().lower()
        config.policy_service_url = parser.get("policy", "service_url", fallback="").strip()
        config.policy_timeout_s = self._get_float(
            parser, "policy", "timeout_s", POLICY_TIMEOUT_DEFAULT_S,
            min_val=POLICY_TIMEOUT_MIN_S, max_val=POLICY_TIMEOUT_MAX_S)
        config.policy_client_cert = parser.get("policy", "client_cert", fallback="").strip()
        config.policy_client_key = parser.get("policy", "client_key", fallback="").strip()
        config.policy_ca = parser.get("policy", "ca", fallback="").strip()
        config.custom_function_write_scm_ids = self._parse_scm_ids(
            parser.get("custom_functions", "allowed_write_scm_ids", fallback=""))
        config.agent_read_exceptions = self._parse_agent_read_exceptions(
            parser.get("policy", "agent_read_exceptions", fallback=""))
        config.test_container_label = (
            parser.get("safety", "test_container_label", fallback="test").strip() or "test")
        config.test_container_name_prefix = (
            parser.get("safety", "test_container_name_prefix", fallback="mcp_").strip() or "mcp_")

        # ── [server] ai_instructions ───────────────────────────────────────────
        config.ai_instructions = parser.get("server", "ai_instructions", fallback="").strip()

        # ── [tokens] scoped MCP tokens (v1.5.0+) ──────────────────────────────
        config.scoped_tokens_enabled = self._get_bool(
            parser, "tokens", "scoped_tokens_enabled", False)
        config.scoped_tokens_required = self._get_bool(
            parser, "tokens", "scoped_tokens_required", False)
        config.legacy_full_token_warn = self._get_bool(
            parser, "tokens", "legacy_full_token_warn", True)
        config.token_default_lifetime_days = self._get_int(
            parser, "tokens", "default_lifetime_days", 90,
            min_val=1, max_val=3650)
        config.token_rate_limit_per_minute = self._get_int(
            parser, "tokens", "rate_limit_per_minute", 120,
            min_val=0, max_val=10000)

        logger.info(
            "[MCP Config] Loaded: %d tools enabled, write=%s, max_results=%d",
            len(config.enabled_tools),
            config.write_tools_enabled,
            config.max_results,
        )

        # Apply asset-level overrides (written by the connector from asset config)
        config = self._apply_asset_overrides(config)

        return config

    def _apply_asset_overrides(self, config: "McpServerConfig") -> "McpServerConfig":
        """
        Apply asset-level overrides from local/asset_overrides.json.

        This file is written by the connector when it reads the asset
        configuration checkboxes (tool_* fields and ai_instructions).
        It takes precedence over everything in mcp.conf.
        """
        import json as _json

        overrides_path = self._app_root / "local" / "asset_overrides.json"
        if not overrides_path.exists():
            return config

        try:
            with open(overrides_path, encoding="utf-8") as fh:
                overrides = _json.load(fh)
        except Exception as exc:
            logger.warning("[MCP Config] Could not read asset_overrides.json: %s", exc)
            return config

        # Apply tool overrides
        tool_overrides = overrides.get("tools")
        if isinstance(tool_overrides, dict):
            new_enabled: set[str] = set()
            for tool in ALL_TOOLS:
                if tool in tool_overrides:
                    if tool_overrides[tool]:
                        new_enabled.add(tool)
                else:
                    # Not in overrides — keep current state from mcp.conf
                    if tool in config.enabled_tools:
                        new_enabled.add(tool)
            config.enabled_tools = new_enabled
            logger.info(
                "[MCP Config] Asset overrides applied: %d tools enabled",
                len(config.enabled_tools),
            )

        # Apply AI instructions override
        ai_instr = overrides.get("ai_instructions")
        if ai_instr and isinstance(ai_instr, str):
            config.ai_instructions = ai_instr.strip()

        # Apply enable_test_harness override (None = not set in asset config → keep mcp.conf value)
        eth = overrides.get("enable_test_harness")
        if eth is not None:
            config.enable_test_harness = bool(eth)

        # Apply policy_enabled override (#144). None = not set in asset config →
        # keep the mcp.conf [policy] value. The UI checkbox takes precedence.
        pol = overrides.get("policy_enabled")
        if pol is not None:
            config.policy_enabled = bool(pol)

        # Policy Manager connection (MCP-G03). None = not set in the asset config
        # -> keep the mcp.conf [policy] value. Empty string = explicitly unset
        # (policy_mode "" = today's path). Values are paths/URLs, never secrets.
        for key in ("policy_mode", "policy_service_url", "policy_client_cert",
                    "policy_client_key", "policy_ca"):
            val = overrides.get(key)
            if val is not None:
                setattr(config, key, str(val).strip().lower() if key == "policy_mode"
                        else str(val).strip())
        timeout = overrides.get("policy_timeout_s")
        if timeout is not None and str(timeout).strip() != "":
            config.policy_timeout_s = self._clamp_float(
                timeout, POLICY_TIMEOUT_DEFAULT_S,
                min_val=POLICY_TIMEOUT_MIN_S, max_val=POLICY_TIMEOUT_MAX_S)

        # Custom Function write allowlist (#159). None = not set in the asset config
        # -> keep the mcp.conf value. The UI field is the intended way to grant this.
        cf_ids = overrides.get("custom_function_write_scm_ids")
        if cf_ids is not None:
            config.custom_function_write_scm_ids = self._parse_scm_ids(cf_ids)

        # Agent read exceptions (MCP-L02). None = not set in the asset config ->
        # keep the mcp.conf value. Empty string = explicitly no exceptions.
        are = overrides.get("agent_read_exceptions")
        if are is not None:
            config.agent_read_exceptions = self._parse_agent_read_exceptions(are)

        ssl_override = overrides.get("ssl_verify")
        if ssl_override is not None:
            if isinstance(ssl_override, bool):
                config.ssl_verify = ssl_override
            else:
                config.ssl_verify = self._parse_ssl_verify(str(ssl_override))

        # Persist MCP endpoint URL so tools can display it
        mcp_ep = overrides.get("mcp_endpoint")
        if mcp_ep and isinstance(mcp_ep, str):
            config.mcp_endpoint = mcp_ep.strip()

        return config

    # ── Helpers ────────────────────────────────────────────────────────────────

    @staticmethod
    def _parse_agent_read_exceptions(raw: object) -> list[str]:
        """Parse the comma-separated agent read-exception list (MCP-L02).

        Fail-safe: only names in READ_ONLY_TOOLS are kept. Unknown names and
        write tools are dropped with a warning — a typo must never widen what
        an agent token may call.
        """
        if isinstance(raw, (list, tuple, set)):
            parts = [str(x) for x in raw]
        else:
            parts = str(raw or "").split(",")
        out: list[str] = []
        for part in parts:
            name = part.strip()
            if not name:
                continue
            if name not in READ_ONLY_TOOLS:
                logger.warning("[MCP Config] Ignoring agent_read_exceptions entry %r: "
                               "not a read-only tool", name)
                continue
            if name not in out:
                out.append(name)
        return out

    @staticmethod
    def _parse_scm_ids(raw: object) -> list[int]:
        """Parse a comma-separated scm_id allowlist. Anything unparsable is dropped
        (fail-safe: a malformed entry must never widen the allowlist)."""
        ids: list[int] = []
        for part in str(raw or "").split(","):
            part = part.strip()
            if not part:
                continue
            try:
                value = int(part)
            except (TypeError, ValueError):
                logger.warning("[MCP Config] Ignoring non-numeric scm_id in "
                               "allowed_write_scm_ids: %r", part)
                continue
            if value > 0 and value not in ids:
                ids.append(value)
        return ids

    @staticmethod
    def _get_bool(parser: configparser.ConfigParser, section: str, key: str, default: bool) -> bool:
        try:
            raw = parser.get(section, key, fallback=None)
            if raw is None:
                return default
            return raw.strip().lower() in ("true", "yes", "1", "on", "enabled")
        except Exception:
            return default

    @staticmethod
    def _get_float(
        parser: configparser.ConfigParser,
        section: str,
        key: str,
        default: float,
        *,
        min_val: float = 0.0,
        max_val: float = float("inf"),
    ) -> float:
        try:
            raw = parser.get(section, key, fallback=None)
            if raw is None:
                return default
            val = float(raw)
            return max(min_val, min(val, max_val))
        except (ValueError, TypeError):
            return default

    @staticmethod
    def _clamp_float(raw: object, default: float, *, min_val: float, max_val: float) -> float:
        """Parse an override value as float within [min_val, max_val]; default on junk."""
        try:
            val = float(raw)  # type: ignore[arg-type]
        except (ValueError, TypeError):
            return default
        return max(min_val, min(val, max_val))

    @staticmethod
    def _get_int(
        parser: configparser.ConfigParser,
        section: str,
        key: str,
        default: int,
        *,
        min_val: int = 0,
        max_val: int = 10_000,
    ) -> int:
        try:
            raw = parser.get(section, key, fallback=None)
            if raw is None:
                return default
            val = int(float(raw))
            return max(min_val, min(val, max_val))
        except (ValueError, TypeError):
            return default

    @staticmethod
    def _parse_ssl_verify(raw: str) -> Union[bool, str]:
        val = raw.strip()
        if val.lower() in ("true", "yes", "1", "on"):
            return True
        if val.lower() in ("false", "no", "0", "off"):
            return False
        # Treat as path
        expanded = os.path.expandvars(os.path.expanduser(val))
        if os.path.isfile(expanded):
            return expanded
        logger.warning("[MCP Config] ssl_verify value '%s' not recognised — defaulting to True.", val)
        return True


# Module-level singleton (lazy-loaded)
_cached_config: Optional[McpServerConfig] = None


def get_config(reload: bool = False) -> McpServerConfig:
    """
    Return the cached McpServerConfig, loading it on first call.

    Args:
        reload: If True, discard the cache and reload from disk.

    Returns:
        McpServerConfig with resolved values.
    """
    global _cached_config
    if _cached_config is None or reload:
        _cached_config = McpConfigLoader().load()
    return _cached_config
