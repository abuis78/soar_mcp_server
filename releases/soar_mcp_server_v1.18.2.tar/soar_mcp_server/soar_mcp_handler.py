"""
SOAR MCP Server — MCP REST Handler
Copyright 2026 Andreas Buis

SOAR Django REST handler pattern (discovered via v1.4.14 diagnostics):
  - SOAR calls SoarMcpRestHandler(django_request, path_args) — request in __init__!
  - SOAR does json.dumps(handler_instance) as the HTTP response body
  - handle() is never called; all logic goes in __init__ (or called from it)
  - Handler must be a dict subclass so json.dumps() works

Request:
  args[0]  = django.core.handlers.wsgi.WSGIRequest
  args[1]  = list of URL path segments, e.g. ['mcp2']

Response:
  self (dict) is serialised by SOAR as the HTTP response body (JSON)
  HTTP status is always 200 from SOAR's side; use JSON-RPC errors for failures
"""

from __future__ import annotations

import json
import logging
import os
import re

# SPEC-MCP MCP-L04: shape of broker context ids (same charset as freigabe_id).
_CONTEXT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._:-]{0,127}$")
import sys

# ── App directory on sys.path ──────────────────────────────────────────────────
_app_dir = os.path.dirname(os.path.abspath(__file__))
if _app_dir not in sys.path:
    sys.path.insert(0, _app_dir)

from soar_mcp_config import GATE_TOOLS, READ_ONLY_TOOLS, McpServerConfig, get_config
from soar_mcp_tools import TOOL_SCHEMAS, SoarApiClient, call_tool
from soar_mcp_utils import redact_nested

try:
    from policy.agent_context import lauf_id_from_arguments
except Exception:  # noqa: BLE001
    lauf_id_from_arguments = None  # type: ignore[assignment]

try:
    from policy.client import approval_ref
except Exception:  # noqa: BLE001
    def approval_ref(freigabe_id: object) -> str:  # type: ignore[no-redef]
        """Fallback (PM-F42): never let a raw approval id reach the audit log."""
        return "<redacted>" if freigabe_id else "-"

try:
    from soar_mcp_tokens import Principal, TokenStore, TokenVerification, sanitise_args_for_audit
except Exception:  # noqa: BLE001
    Principal = None  # type: ignore[misc,assignment]
    TokenStore = None  # type: ignore[misc,assignment]
    TokenVerification = None  # type: ignore[misc,assignment]

    def sanitise_args_for_audit(args: dict) -> dict:  # type: ignore[no-redef]
        """Return a copy of args safe for audit logging: sensitive values redacted, strings truncated."""
        try:
            return redact_nested(args)
        except Exception:
            return {"_redaction_error": "sanitisation failed"}

import hashlib

# Rate limiter for the legacy ph-auth-token path (issue #44). Scoped tokens are
# rate-limited inside the token store; without this the default legacy path is
# unbounded. Per-process only — use a reverse-proxy limit for a hard DoS ceiling.
try:
    from soar_mcp_tokens import _RateLimiter as _LegacyRateLimiter
    _legacy_rate_limiter = _LegacyRateLimiter()
except Exception:  # noqa: BLE001
    _legacy_rate_limiter = None

logger = logging.getLogger(__name__)
audit_logger = logging.getLogger("soar_mcp.audit")

# ── Handler URL constants ──────────────────────────────────────────────────────
_APPID = "ff5f68f3-353c-4d89-9767-967ef5d99117"
_HANDLER_DIR = f"soarmcpserver_{_APPID}"

_JSONRPC_PARSE_ERROR      = -32700
_JSONRPC_INVALID_REQUEST  = -32600
_JSONRPC_METHOD_NOT_FOUND = -32601
_JSONRPC_INVALID_PARAMS   = -32602
_JSONRPC_INTERNAL_ERROR   = -32603


class _InvalidParamsError(Exception):
    """Raised when a JSON-RPC call has invalid or missing parameters (maps to -32602)."""


def build_mcp_endpoint(base_url: str, asset_name: str) -> str:
    return f"{base_url.rstrip('/')}/rest/handler/{_HANDLER_DIR}/{asset_name}"


# ── SOAR Django REST handler ───────────────────────────────────────────────────

class SoarMcpRestHandler(dict):
    """
    SOAR REST handler for the MCP server.

    SOAR's Django framework passes the WSGIRequest to __init__ and
    serialises this dict instance as the HTTP response body.
    All request processing happens in __init__ (via _process).
    """

    def __init__(self, request=None, path_args=None, *args, **kwargs):
        super().__init__()
        try:
            response = self._process(request, path_args or [])
        except Exception as exc:
            # Detail is logged server-side only; never echoed to the client (#57).
            logger.exception("[SOAR MCP] Fatal error in __init__: %s", exc)
            response = self._error(None, _JSONRPC_INTERNAL_ERROR,
                                   "Internal MCP handler error.")
        self.update(response)

    # ── Request processing ─────────────────────────────────────────────────────

    def _process(self, request, path_args: list) -> dict:
        # Load config (tool enable/disable, AI instructions)
        try:
            config = get_config(reload=True)
        except Exception:
            config = McpServerConfig()

        # Extract HTTP method
        method = getattr(request, "method", "POST").upper() if request else "POST"

        # Extract auth token from Django META.
        #
        # SOAR's outer Django auth layer authenticates requests *before* they
        # reach this handler. In practice it only honours `ph-auth-token`;
        # `Authorization: Bearer <token>` is rejected upstream with
        # "Invalid JWT" and never gets here, so the previous Bearer fallback
        # was dead code. We still read both keys so a future SOAR release
        # (or a reverse proxy that rewrites headers) can pass either form.
        meta = getattr(request, "META", {}) or {}
        auth_token = (
            meta.get("HTTP_PH_AUTH_TOKEN", "")
            or meta.get("HTTP_AUTHORIZATION", "").replace("Bearer ", "").strip()
        ).strip()

        # Cursor / Streamable HTTP MCP clients may send Mcp-Session-Id;
        # we don't track sessions server-side but accept and ignore it.
        session_id = meta.get("HTTP_MCP_SESSION_ID", "")

        # Extract base URL from request for API callbacks
        soar_base = self._extract_base_url(request, config)

        # Persist asset name for widget
        asset_name = path_args[0] if path_args else ""
        if asset_name and soar_base:
            self._persist_endpoint(soar_base, asset_name)

        # Handle GET (SSE endpoint — return minimal SSE compatible response)
        if method == "GET":
            # SOAR serialises this dict as body; wrap SSE-like response in JSON
            return {"event": "endpoint", "data": {}}

        # Handle OPTIONS (CORS preflight)
        if method == "OPTIONS":
            return {}

        # Parse request body
        body_bytes = b""
        if request is not None:
            try:
                body_bytes = request.body  # bytes in Django
            except Exception:
                pass

        if not body_bytes:
            return self._error(None, _JSONRPC_PARSE_ERROR, "Empty request body")

        # Parse JSON-RPC
        try:
            rpc = json.loads(body_bytes)
        except (json.JSONDecodeError, TypeError) as exc:
            logger.info("[SOAR MCP] JSON parse error: %s", exc)
            return self._error(None, _JSONRPC_PARSE_ERROR, "Invalid JSON in request body.")

        if not isinstance(rpc, dict):
            return self._error(None, _JSONRPC_INVALID_REQUEST, "Request must be a JSON object")

        rpc_id     = rpc.get("id")
        rpc_method = rpc.get("method", "")
        params     = rpc.get("params") or {}

        logger.info("[SOAR MCP] %s (id=%s)", rpc_method, rpc_id)

        # Require auth for all methods except initialize/notifications/ping
        if not auth_token:
            return self._error(rpc_id, -32000,
                "Missing ph-auth-token header. Add it to your MCP client configuration.")

        # Resolve auth: scoped MCP token (preferred) or legacy SOAR ph-auth-token.
        # Scoped tokens are looked up in the app's local token store; if found,
        # the bound SOAR service token is used to call the SOAR API and tool
        # access is further restricted to the scoped allow-list.
        token_verification = None
        soar_call_token = auth_token
        if TokenStore is not None and config.scoped_tokens_enabled:
            try:
                store = TokenStore.default()
                token_verification = store.verify(
                    auth_token,
                    rate_limit=config.token_rate_limit_per_minute,
                )
            except Exception as exc:  # noqa: BLE001
                logger.exception("[SOAR MCP] Token store error: %s", exc)
                token_verification = None

            if token_verification is not None:
                if not token_verification.valid:
                    audit_logger.warning(
                        "[SOAR MCP] auth=reject reason=%s rpc_method=%s",
                        token_verification.reason, rpc_method,
                    )
                    return self._error(rpc_id, -32000,
                        f"MCP token rejected: {token_verification.reason}")
                soar_call_token = token_verification.soar_call_token or auth_token

        if token_verification is None and config.scoped_tokens_required:
            audit_logger.warning(
                "[SOAR MCP] auth=reject reason=legacy_token_blocked rpc_method=%s",
                rpc_method,
            )
            return self._error(rpc_id, -32000,
                "This SOAR MCP instance requires a scoped MCP token. "
                "Ask a SOAR admin to mint one with the 'mint mcp token' action.")

        if token_verification is None and config.legacy_full_token_warn:
            logger.info("[SOAR MCP] Legacy full ph-auth-token used (rpc_method=%s)", rpc_method)

        # Rate-limit the legacy ph-auth-token path too (#44). Keyed on a hash of
        # the presented token so the raw token is never used as a dict key.
        if (token_verification is None
                and _legacy_rate_limiter is not None
                and config.token_rate_limit_per_minute > 0):
            legacy_key = "legacy:" + hashlib.sha256(auth_token.encode()).hexdigest()[:16]
            if not _legacy_rate_limiter.check(legacy_key, config.token_rate_limit_per_minute):
                audit_logger.warning(
                    "[SOAR MCP] auth=reject reason=rate_limited path=legacy rpc_method=%s",
                    rpc_method,
                )
                return self._error(rpc_id, -32000, "Rate limit exceeded. Try again shortly.")

        # Tool calls need a usable base URL. Fail with a clear, actionable error
        # rather than letting a scheme-less/empty base_url produce opaque
        # "MissingSchema" errors deep in every tool (base_url regression).
        # Exception (#122): the read-only diagnostics tool is allowed through
        # even without a base URL — its whole job is to report *why* the endpoint
        # is unusable (e.g. base_url lost after an app upgrade wiped local/).
        _tool_name = (params.get("name") or "").strip() if isinstance(params, dict) else ""
        if rpc_method == "tools/call" and not soar_base \
                and _tool_name != "diagnose_soar_mcp_environment":
            return self._error(rpc_id, _JSONRPC_INTERNAL_ERROR,
                "Could not determine the SOAR base URL. Set 'base_url' in the SOAR "
                "MCP Server asset configuration and run Test Connectivity. "
                "(An app upgrade can remove local/ — re-run Test Connectivity after "
                "upgrading; see the README 'Upgrades' note.)")

        # Build SOAR API client for tool calls
        client = SoarApiClient(soar_base, soar_call_token, config)

        # Dispatch JSON-RPC method
        try:
            if rpc_method == "initialize":
                result = self._handle_initialize(params, config)
            elif rpc_method == "notifications/initialized":
                return {}   # Notification — empty response is correct
            elif rpc_method == "tools/list":
                result = self._handle_tools_list(config, token_verification)
            elif rpc_method == "tools/call":
                result = self._handle_tools_call(
                    params, client, config, token_verification,
                )
            elif rpc_method == "ping":
                result = {}
            else:
                return self._error(rpc_id, _JSONRPC_METHOD_NOT_FOUND,
                                   f"Method not found: {rpc_method}")
        except _InvalidParamsError as exc:
            # Fix #12: return -32602 Invalid Params for bad tool call arguments
            return self._error(rpc_id, _JSONRPC_INVALID_PARAMS, str(exc))
        except Exception as exc:
            logger.exception("[SOAR MCP] Error in method %s: %s", rpc_method, exc)
            return self._error(rpc_id, _JSONRPC_INTERNAL_ERROR, "Internal server error")

        return {"jsonrpc": "2.0", "id": rpc_id, "result": result}

    # ── MCP method implementations ─────────────────────────────────────────────

    def _handle_initialize(self, params: dict, config: McpServerConfig) -> dict:
        base = (
            "You are connected to a Splunk SOAR (Security Orchestration, Automation & Response) "
            "instance via the Model Context Protocol.\n\n"
            "SOAR manages incidents ('cases'), IOC observables ('artifacts'), analyst notes, "
            "and automated response playbooks.\n\n"
            "How to work effectively:\n"
            "- Start with list_cases or search_cases to find relevant incidents.\n"
            "- Use get_case for full case details (status, severity, owner, description).\n"
            "- Use list_artifacts to see IOCs (IPs, domains, hashes, emails, URLs).\n"
            "- Use list_case_notes to read investigation history and analyst findings.\n"
            "- Use list_playbooks to discover available automated response options.\n"
            "- Severity: high > medium > low > informational.\n"
            "- Status: new, open, in_progress, resolved, closed.\n\n"
            "Write tools (add_case_note, run_playbook, update_case_status, etc.) modify live "
            "SOAR data. Always describe what you plan to do and wait for confirmation before "
            "executing write operations."
        )
        custom = (config.ai_instructions or "").strip()
        instructions = (base + "\n\n--- Environment context ---\n" + custom) if custom else base

        return {
            "protocolVersion": config.protocol_version,
            "capabilities": {"tools": {"listChanged": False}},
            "serverInfo": {"name": config.server_name, "version": config.server_version},
            "instructions": instructions,
        }

    # Tools whose real function is not yet available on any verified SOAR
    # version, so they must NOT be advertised in tools/list as functional
    # (issue #65). save_playbook_layout_only can only preview (dry_run); its
    # actual write path is blocked until the COA write endpoint is live-verified
    # (see VERIFICATION.md). Hidden from discovery; a direct dry_run call is
    # still honoured by _handle_tools_call for anyone who already knows the name.
    _HIDDEN_FROM_LIST = frozenset({"save_playbook_layout_only"})

    @staticmethod
    def _agent_read_blocked(tool_name: str, config: McpServerConfig,
                            token_verification=None) -> bool:
        """SPEC-MCP MCP-L01/L02: an 'agent' principal gets no direct read tools.

        True when the caller is an agent-principal scoped token AND tool_name is
        a read-only tool that is not on the admin-justified exception list
        (config.agent_read_exceptions). Single source of truth for tools/list
        (hide) and tools/call (reject) so the two can never disagree. Humans,
        brokers and the legacy full-token path are never blocked here.
        """
        if token_verification is None:
            return False
        if getattr(token_verification, "principal_type", "mensch") != "agent":
            return False
        if tool_name not in READ_ONLY_TOOLS:
            return False
        return tool_name not in set(getattr(config, "agent_read_exceptions", []) or [])

    @staticmethod
    def _broker_write_blocked(tool_name: str, token_verification=None) -> bool:
        """SPEC-MCP MCP-L05 / AC-07 / concept OQ-14 (Phase 4.1): a broker token
        reads only. Every tool outside READ_ONLY_TOOLS (write and approval
        tools) is hidden from tools/list and refused on tools/call, even when
        allowed_tools names it. One predicate for both, so hidden == refused."""
        if token_verification is None or tool_name in READ_ONLY_TOOLS:
            return False
        return getattr(token_verification, "principal_type", "mensch") == "broker"

    @staticmethod
    def _is_broker(token_verification=None) -> bool:
        return (token_verification is not None
                and getattr(token_verification, "principal_type", "mensch") == "broker")

    @staticmethod
    def _broker_context_problem(arguments: dict) -> str:
        """MCP-L04: '' when the broker context is usable, else the refusal text.
        broker_aufruf_id is required (1-128 chars of [A-Za-z0-9._:-]); agent_id
        and lauf_id are optional but, when given, must be strings of that shape."""
        args = arguments if isinstance(arguments, dict) else {}
        aufruf = args.get("broker_aufruf_id")
        if not isinstance(aufruf, str) or not _CONTEXT_ID_RE.match(aufruf.strip()):
            return ("broker_aufruf_id is required for broker tokens (MCP-L04): pass the Tool Broker's "
                    "aufruf_id (1-128 characters, letters/digits/._:-) as a top-level argument. "
                    "Optional context: agent_id, lauf_id.")
        for key in ("agent_id", "lauf_id"):
            val = args.get(key)
            if val is not None and (not isinstance(val, str) or not _CONTEXT_ID_RE.match(val.strip())):
                return f"{key} must be a string of 1-128 characters (letters/digits/._:-) when given (MCP-L04)."
        return ""

    @staticmethod
    def _cap_broker_limit(arguments: dict, config: McpServerConfig) -> dict:
        """MCP-L04: a broker never gets more than max_results per call. Tools
        without a limit parameter are unaffected (see README)."""
        cap = int(getattr(config, "max_results", 50) or 50)
        limit = arguments.get("limit")
        if isinstance(limit, bool) or not isinstance(limit, (int, float)):
            return arguments
        if int(limit) <= cap:
            return arguments
        capped = dict(arguments)
        capped["limit"] = cap
        logger.info("[SOAR MCP] broker limit %s capped to max_results=%s", limit, cap)
        return capped

    @staticmethod
    def _human_only_blocked(tool_name: str, token_verification=None) -> bool:
        """SPEC-MCP MCP-W06 (Phase 3.4): gate tools (approve_action) are for
        humans. Agent and broker tokens neither see nor call them; one predicate
        for tools/list and tools/call. Humans and the legacy full token see the
        tool (the legacy call is refused inside the tool: no approver identity)."""
        if tool_name not in GATE_TOOLS or token_verification is None:
            return False
        return getattr(token_verification, "principal_type", "mensch") in ("agent", "broker")

    def _handle_tools_list(self, config: McpServerConfig,
                           token_verification=None) -> dict:
        # Scoped token allow-list intersects with asset-config enabled tools.
        allowed = set(config.enabled_tools)
        if token_verification is not None and token_verification.allowed_tools is not None:
            allowed &= set(token_verification.allowed_tools)

        tools = [
            {"name": name, "description": schema["description"],
             "inputSchema": schema["inputSchema"]}
            for name, schema in TOOL_SCHEMAS.items()
            if name in allowed and name not in self._HIDDEN_FROM_LIST
            and not self._agent_read_blocked(name, config, token_verification)
            and not self._human_only_blocked(name, token_verification)
            and not self._broker_write_blocked(name, token_verification)
        ]
        logger.info("[SOAR MCP] tools/list → %d tools", len(tools))
        return {"tools": tools}

    def _handle_tools_call(self, params: dict, client: SoarApiClient,
                           config: McpServerConfig,
                           token_verification=None) -> dict:
        tool_name = (params.get("name") or "").strip()
        arguments = params.get("arguments") or {}

        if not tool_name:
            # Return -32602 Invalid Params (not -32603 Internal Server Error) (fix #12)
            raise _InvalidParamsError("tools/call requires a non-empty 'name' parameter")

        safe_layout_preview = (
            tool_name == "save_playbook_layout_only"
            and bool(arguments.get("dry_run", True))
        )
        if tool_name not in config.enabled_tools and not safe_layout_preview:
            if tool_name in TOOL_SCHEMAS:
                text = (f"Tool '{tool_name}' is disabled. Enable it in the SOAR MCP Server "
                        f"asset configuration and run Test Connectivity.")
            else:
                text = f"Unknown tool '{tool_name}'. Call tools/list to see available tools."
            self._audit_tool_call(token_verification, tool_name, arguments,
                                  outcome="denied:disabled")
            return {"content": [{"type": "text", "text": text}], "isError": True}

        if (token_verification is not None
                and token_verification.allowed_tools is not None
                and tool_name not in token_verification.allowed_tools):
            text = (f"Tool '{tool_name}' is not in this MCP token's allow-list. "
                    f"Allowed: {sorted(token_verification.allowed_tools) or 'none'}")
            self._audit_tool_call(token_verification, tool_name, arguments,
                                  outcome="denied:scoped")
            return {"content": [{"type": "text", "text": text}], "isError": True}

        # SPEC-MCP MCP-L01/L02: agent-principal tokens get no direct read tools.
        # Same predicate as tools/list, so hidden == rejected. An admin-listed
        # exception (agent_read_exceptions) proceeds but is marked in the audit.
        outcome = "ok"
        if self._agent_read_blocked(tool_name, config, token_verification):
            agent_id = getattr(token_verification, "agent_id", None) or "-"
            text = (f"\u26d4 USE_TOOL_BROKER \u2014 Tool '{tool_name}' is a direct SOAR read tool "
                    f"and is not available to agent tokens. Read SOAR data through the "
                    f"Tool Broker template for this need (agent_id={agent_id}).")
            self._audit_tool_call(token_verification, tool_name, arguments,
                                  outcome="denied:use_tool_broker")
            return {"content": [{"type": "text", "text": text}], "isError": True}
        if (token_verification is not None
                and getattr(token_verification, "principal_type", "mensch") == "agent"
                and tool_name in READ_ONLY_TOOLS):
            outcome = "ok:agent_read_exception"
        if self._broker_write_blocked(tool_name, token_verification):
            text = (f"\u26d4 Tool '{tool_name}' is not a read tool. Broker tokens (principal_type = broker) "
                    "can only call tools from READ_ONLY_TOOLS, regardless of their allow-list (MCP-L05).")
            self._audit_tool_call(token_verification, tool_name, arguments,
                                  outcome="denied:broker_write")
            return {"content": [{"type": "text", "text": text}], "isError": True}
        if self._human_only_blocked(tool_name, token_verification):
            text = (f"\u26d4 Tool '{tool_name}' is reserved for human analysts with a scoped MCP token "
                    f"(principal_type = mensch); {getattr(token_verification, 'principal_type', '-')} "
                    "tokens cannot approve actions.")
            self._audit_tool_call(token_verification, tool_name, arguments,
                                  outcome="denied:human_only")
            return {"content": [{"type": "text", "text": text}], "isError": True}
        # SPEC-MCP MCP-L04 (Phase 4.2): a broker call carries the broker's
        # context — broker_aufruf_id is the audit evidence and mandatory;
        # agent_id / lauf_id are optional. Results are capped at max_results.
        if self._is_broker(token_verification):
            problem = self._broker_context_problem(arguments)
            if problem:
                self._audit_tool_call(token_verification, tool_name, arguments,
                                      outcome="denied:missing_broker_aufruf_id")
                return {"content": [{"type": "text", "text": "\u26d4 " + problem}], "isError": True}
            arguments = self._cap_broker_limit(arguments, config)

        self._audit_tool_call(token_verification, tool_name, arguments, outcome=outcome)
        # Scoped-token identity is the accountable approver for the policy layer
        # (#138); legacy full tokens have no bound user -> None (fail-safe HOLD).
        actor_id = token_verification.soar_user_id if token_verification is not None else None
        # SPEC-MCP MCP-W04: the full caller identity (type, token_id, agent_id)
        # for the Policy Manager adapter. Legacy ph-auth-token -> mensch, legacy.
        principal = Principal.from_verification(token_verification) if Principal is not None else None
        result_text = call_tool(tool_name, arguments, client, config,
                                actor_id=actor_id, principal=principal)
        is_error = self._is_tool_error(result_text)
        self._audit_tool_result(token_verification, tool_name, arguments,
                                result=self._classify_result(result_text, is_error))
        return {"content": [{"type": "text", "text": result_text}], "isError": is_error}

    @staticmethod
    def _classify_result(result_text: str, is_error: bool) -> str:
        """Audit classification of a tool result (SPEC-MCP MCP-G05).

        policy_blocked (⛔) and policy_hold (⏸) are the policy gate's own
        markers; everything else is ok / error from _is_tool_error.
        """
        head = (result_text or "").lstrip()[:4]
        if head.startswith("\u26d4"):
            return "policy_blocked"
        if head.startswith("\u23f8"):
            return "policy_hold"
        return "error" if is_error else "ok"

    @staticmethod
    def _is_tool_error(result_text: str) -> bool:
        """Best-effort MCP isError flag for existing text and structured JSON tool outputs."""
        text = result_text.lstrip()
        if text.startswith(("Error:", "Error ")):
            return True
        try:
            payload = json.loads(text)
        except Exception:
            return False
        if isinstance(payload, dict):
            return payload.get("ok") is False or bool(payload.get("errors"))
        return False

    @staticmethod
    def _audit_tool_call(token_verification, tool_name: str,
                         arguments: dict, *, outcome: str) -> None:
        """Emit a structured audit line. Never logs the token itself."""
        safe_args = sanitise_args_for_audit(arguments)
        if isinstance(safe_args, dict) and safe_args.get("freigabe_id"):
            # PM-F42 / S14: approval ids never in clear text; the hash equals the
            # Policy Manager's freigabe_hash, so the audits still correlate.
            safe_args["freigabe_id"] = "#" + approval_ref(safe_args["freigabe_id"])
        audit_logger.info(
            "[SOAR MCP] tool_call outcome=%s tool=%s %s args=%s",
            outcome, tool_name,
            SoarMcpRestHandler._audit_identity(token_verification, arguments),
            json.dumps(safe_args, default=str)[:500],
        )

    @staticmethod
    def _audit_tool_result(token_verification, tool_name: str,
                           arguments: dict, *, result: str) -> None:
        """Second audit line, AFTER the tool ran (SPEC-MCP MCP-G05): what came
        back — ok / error / policy_blocked / policy_hold. Decision and approval
        ids (entscheidung_id / freigabe_id) will be appended here in Phase 2."""
        audit_logger.info(
            "[SOAR MCP] tool_result result=%s tool=%s %s",
            result, tool_name,
            SoarMcpRestHandler._audit_identity(token_verification, arguments),
        )

    @staticmethod
    def _audit_identity(token_verification, arguments: dict) -> str:
        """Caller identity fields shared by both audit lines (MCP-G05):
        principal (mensch|agent|broker|legacy), token_id, label, agent_id, plus
        lauf_id / broker_aufruf_id when the caller passed them as top-level
        arguments (Phase 1: logged only, not enforced). Never the token value."""
        tv = token_verification
        token_id = getattr(tv, "token_id", None) if tv else None
        label = getattr(tv, "label", None) if tv else None
        principal = (getattr(tv, "principal_type", None) or "mensch") if tv else "legacy"
        agent_id = getattr(tv, "agent_id", None) if tv else None
        args = arguments if isinstance(arguments, dict) else {}
        if principal == "broker" and not agent_id:
            # Phase 4.2 (MCP-L04): the broker names the agent it reads for.
            agent_id = args.get("agent_id")

        def _s(v: object) -> str:
            v = str(v).strip() if v is not None else ""
            return v[:64] if v else "-"

        # lauf_id: agent_context.lauf_id first (Phase 2, OQ-12), then the
        # Phase-1 top-level argument.
        lauf_id = lauf_id_from_arguments(args) if lauf_id_from_arguments is not None else args.get("lauf_id")
        return (f"principal={principal} token_id={token_id or 'legacy'} label={label or '-'} "
                f"agent_id={_s(agent_id)} lauf_id={_s(lauf_id)} "
                f"broker_aufruf_id={_s(args.get('broker_aufruf_id'))}")

    # ── Helpers ────────────────────────────────────────────────────────────────

    @staticmethod
    def _error(rpc_id, code: int, message: str) -> dict:
        return {"jsonrpc": "2.0", "id": rpc_id,
                "error": {"code": code, "message": message}}

    @staticmethod
    def _normalize_base_url(url: str) -> str:
        """Return a scheme-qualified base URL, or "" if it can't be made safe.

        Guards against the MissingSchema class of bugs: a scheme-less value
        (e.g. a bare host from some SOAR builds) would otherwise be handed to
        requests and blow up on every API call. Trusted sources missing a
        scheme default to https (never http). Non-http schemes are rejected.
        """
        if not url:
            return ""
        url = url.strip().rstrip("/")
        # Reject embedded credentials (user:pass@host) regardless of scheme (#93).
        host_part = url.split("://", 1)[-1]
        if "@" in host_part.split("/", 1)[0]:
            logger.warning("[SOAR MCP] Ignoring base_url with embedded credentials.")
            return ""
        if re.match(r"^https?://", url, re.I):
            return url
        if "://" not in url:
            return "https://" + url
        return ""

    @staticmethod
    def _read_configured_base_url() -> str:
        """Operator-configured base_url persisted by the connector (asset config).
        Trusted — NOT a request header — so using it does not reintroduce #58."""
        try:
            path = os.path.join(_app_dir, "local", "asset_overrides.json")
            if os.path.exists(path):
                with open(path, encoding="utf-8") as fh:
                    return (json.load(fh).get("base_url") or "").strip()
        except Exception:
            pass
        return ""

    @staticmethod
    def _extract_base_url(request, config=None) -> str:
        # Security (issue #58): the returned base_url is used to build the
        # SoarApiClient that sends the SOAR call token. It must come from a
        # TRUSTED source, NEVER from attacker-controllable request headers
        # (Host / X-Forwarded-*), which could redirect token-bearing API calls
        # to an attacker host (SSRF/credential exfil).
        #
        # Trusted sources, in order (all admin-controlled, never request headers):
        #   1. phantom.rest.get_phantom_base_url() — authoritative on-box.
        #   2. mcp.conf [server] base_url — static admin config, survives across
        #      reinstalls better than local/ (issue #93, contributed by @reisball).
        #   3. asset-config base_url persisted to local/asset_overrides.json by
        #      Test Connectivity.
        # Fail closed ("") if none yields a scheme-qualified URL.
        cls = SoarMcpRestHandler
        try:
            import phantom.rest as _pr
            url = cls._normalize_base_url(_pr.get_phantom_base_url() or "")
            if url:
                return url
        except Exception:
            pass
        if config is not None and getattr(config, "base_url", ""):
            url = cls._normalize_base_url(config.base_url)
            if url:
                return url
        url = cls._normalize_base_url(cls._read_configured_base_url())
        if url:
            return url
        logger.warning("[SOAR MCP] Could not resolve SOAR base URL from phantom.rest, "
                       "mcp.conf, or asset config; refusing to derive it from request headers.")
        return ""

    @staticmethod
    def _persist_endpoint(base_url: str, asset_name: str) -> None:
        try:
            overrides_path = os.path.join(_app_dir, "local", "asset_overrides.json")
            if not os.path.exists(overrides_path):
                return
            with open(overrides_path, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            endpoint = build_mcp_endpoint(base_url, asset_name)
            if data.get("mcp_endpoint") == endpoint:
                return
            data["mcp_endpoint"] = endpoint
            data["asset_name"]   = asset_name
            data["base_url"]     = base_url
            with open(overrides_path, "w", encoding="utf-8") as fh:
                json.dump(data, fh, indent=2)
        except Exception:
            pass

    # ── Legacy handle() stub (never called by SOAR but kept for local testing) ─

    def handle(self, in_string: str) -> dict:
        """Not called by SOAR — kept for local standalone test server only."""
        return {"status": 200, "headers": {"Content-Type": "application/json"},
                "payload": json.dumps(dict(self))}

    def handleStream(self, handle, in_string):
        return None

    def done(self):
        pass


# ── Standalone test server ─────────────────────────────────────────────────────

def run_standalone_server(host: str = "localhost", port: int = 8743) -> None:
    """Local test server that mimics SOAR's handler invocation pattern."""
    import http.server

    class _MockRequest:
        def __init__(self, method, body, meta):
            self.method = method
            self.body = body
            self.META = meta

        def build_absolute_uri(self, path="/"):
            return f"http://localhost:{port}{path}"

    class _H(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt, *args):
            pass

        def _handle(self, method, body=b""):
            meta = {f"HTTP_{k.upper().replace('-','_')}": v
                    for k, v in self.headers.items()}
            meta["SERVER_NAME"] = host
            req = _MockRequest(method, body, meta)
            path = self.path.split("/")[-1] or "test"
            handler = SoarMcpRestHandler(req, [path])
            body_out = json.dumps(dict(handler)).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body_out)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.end_headers()
            self.wfile.write(body_out)

        def do_GET(self):    self._handle("GET")
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            self._handle("POST", self.rfile.read(n))
        def do_OPTIONS(self):
            self.send_response(200)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Headers",
                             "ph-auth-token, Content-Type")
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            self.end_headers()

    server = http.server.HTTPServer((host, port), _H)
    print(f"[SOAR MCP] Standalone server at http://{host}:{port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n[SOAR MCP] Stopped.")


if __name__ == "__main__":
    import argparse
    logging.basicConfig(level=logging.INFO)
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="localhost")
    parser.add_argument("--port", type=int, default=8743)
    args = parser.parse_args()
    run_standalone_server(host=args.host, port=args.port)
