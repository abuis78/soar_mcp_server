"""
SOAR MCP Server — Tool Definitions and Implementations

Each function here corresponds to one MCP tool that an AI client (Claude, etc.)
can invoke. All tools call the Splunk SOAR REST API using the auth token supplied
by the MCP client in the request headers.

Design principles:
  - Read-only tools are safe and enabled by default.
  - Write tools (add_case_note, run_playbook, etc.) are disabled by default.
  - All responses are human-readable text blocks (MCP content type "text").
  - Errors are returned as structured error text, not raised exceptions.
  - No tool modifies SOAR state unless explicitly enabled in mcp.conf.

SOAR REST API base: https://<soar>/rest/
Auth header:        ph-auth-token: <token>

Copyright 2026 Andreas Buis
"""

from __future__ import annotations

import json
import logging
import re
from typing import Any, Optional

import requests

from soar_mcp_config import McpServerConfig

# ── Security constants ─────────────────────────────────────────────────────────
_MAX_NOTE_LENGTH = 10_000   # characters — prevents storage exhaustion (issue #11)
_HTML_TAG_RE = re.compile(r'<[^>]+>')  # used to strip HTML from note content


def _require_positive_int(value: Any, name: str) -> tuple[int | None, str | None]:
    """
    Validate that *value* is (or can be cast to) a positive integer.

    Returns (int_value, None) on success or (None, error_string) on failure.
    Prevents path-traversal attacks where string IDs like '1/../../ph_user' are
    interpolated directly into REST API URLs (security issue #9).
    """
    try:
        v = int(value)
        if v <= 0:
            raise ValueError
        return v, None
    except (TypeError, ValueError):
        return None, f"Error: {name} must be a positive integer, got: {value!r}"

logger = logging.getLogger(__name__)

# ── SOAR severity ordering (for min_severity filtering) ───────────────────────
_SEVERITY_ORDER = {"high": 4, "medium": 3, "low": 2, "informational": 1, "": 0}

# ── SOAR status labels ─────────────────────────────────────────────────────────
_VALID_STATUSES = {"open", "closed", "resolved", "new"}
_VALID_SEVERITIES = {"high", "medium", "low", "informational"}


# ==============================================================================
# HTTP helper
# ==============================================================================


class SoarApiClient:
    """Thin wrapper around the SOAR REST API."""

    def __init__(self, base_url: str, auth_token: str, config: McpServerConfig) -> None:
        self._base_url = base_url.rstrip("/")
        self._auth_token = auth_token
        self._config = config
        self._session = requests.Session()
        self._session.headers.update({
            "ph-auth-token": auth_token,
            "Content-Type": "application/json",
            "Accept": "application/json",
        })
        self._session.verify = config.ssl_verify

    def get(self, path: str, params: dict | None = None) -> tuple[dict | list | None, str | None]:
        """GET request. Returns (data, error_message)."""
        url = f"{self._base_url}/rest/{path.lstrip('/')}"
        try:
            resp = self._session.get(url, params=params, timeout=self._config.timeout)
            return self._handle_response(resp)
        except requests.exceptions.Timeout:
            return None, f"SOAR REST API timed out after {self._config.timeout}s"
        except requests.exceptions.SSLError as e:
            return None, f"SSL error: {e}"
        except requests.exceptions.ConnectionError as e:
            return None, f"Connection error: {e}"
        except Exception as e:
            return None, f"Unexpected error: {type(e).__name__}"

    def post(self, path: str, body: dict) -> tuple[dict | None, str | None]:
        """POST request. Returns (data, error_message)."""
        url = f"{self._base_url}/rest/{path.lstrip('/')}"
        try:
            resp = self._session.post(url, json=body, timeout=self._config.timeout)
            return self._handle_response(resp)
        except requests.exceptions.Timeout:
            return None, f"SOAR REST API timed out after {self._config.timeout}s"
        except requests.exceptions.ConnectionError as e:
            return None, f"Connection error: {e}"
        except Exception as e:
            return None, f"Unexpected error: {type(e).__name__}"

    def get_binary(self, path: str, params: dict | None = None) -> tuple[bytes | None, str | None]:
        """GET request returning raw bytes (for binary endpoints like playbook export)."""
        url = f"{self._base_url}/rest/{path.lstrip('/')}"
        try:
            resp = self._session.get(url, params=params, timeout=self._config.timeout)
            if resp.status_code == 401:
                return None, "Authentication failed (HTTP 401). Check ph-auth-token."
            if resp.status_code == 403:
                return None, "Access denied (HTTP 403). Token may lack required permissions."
            if resp.status_code == 404:
                return None, "Resource not found (HTTP 404)."
            if resp.status_code >= 400:
                return None, f"SOAR API error HTTP {resp.status_code}: {resp.text[:200]}"
            return resp.content, None
        except requests.exceptions.Timeout:
            return None, f"SOAR REST API timed out after {self._config.timeout}s"
        except requests.exceptions.SSLError as e:
            return None, f"SSL error: {e}"
        except requests.exceptions.ConnectionError as e:
            return None, f"Connection error: {e}"
        except Exception as e:
            return None, f"Unexpected error: {type(e).__name__}"

    def _handle_response(self, resp: requests.Response) -> tuple[Any, str | None]:
        if resp.status_code == 401:
            return None, "Authentication failed (HTTP 401). Check ph-auth-token in the MCP client config."
        if resp.status_code == 403:
            return None, "Access denied (HTTP 403). Token may lack required permissions."
        if resp.status_code == 404:
            return None, "Resource not found (HTTP 404)."
        if resp.status_code >= 400:
            try:
                err_body = resp.json()
                msg = err_body.get("message") or err_body.get("error") or resp.text[:300]
            except Exception:
                msg = resp.text[:300]
            return None, f"SOAR API error HTTP {resp.status_code}: {msg}"
        try:
            return resp.json(), None
        except Exception:
            return {"raw": resp.text}, None


def _disclaimer() -> str:
    return (
        "\n\n---\n"
        "⚠️  Advisory: This data is provided for analysis only. "
        "Any write operations (notes, status changes, playbook runs) must be "
        "reviewed and confirmed by a human analyst before execution."
    )


def _fmt_case(c: dict) -> str:
    """Format a single case dict as readable text."""
    sev = c.get("severity", "unknown")
    status = c.get("status", "unknown")
    owner = c.get("owner_name") or c.get("owner") or "unassigned"
    label = c.get("label", "")
    tags = ", ".join(c.get("tags", []) or []) or "none"
    return (
        f"  ID: {c.get('id')} | {c.get('name', '(untitled)')}\n"
        f"    Status: {status} | Severity: {sev} | Owner: {owner} | Label: {label}\n"
        f"    Tags: {tags} | Created: {c.get('create_time', 'unknown')}"
    )


def _fmt_artifact(a: dict) -> str:
    """Format a single artifact as readable text."""
    cef = a.get("cef") or {}
    cef_str = ", ".join(f"{k}={v}" for k, v in list(cef.items())[:8]) if cef else "none"
    return (
        f"  ID: {a.get('id')} | Type: {a.get('type', 'unknown')} | "
        f"Name: {a.get('name', '(unnamed)')}\n"
        f"    CEF fields: {cef_str}\n"
        f"    Source: {a.get('source_data_identifier', 'unknown')} | "
        f"Created: {a.get('create_time', 'unknown')}"
    )


# ==============================================================================
# MCP Tool schema definitions
# ==============================================================================

TOOL_SCHEMAS: dict[str, dict] = {
    "list_cases": {
        "description": (
            "List SOAR cases (containers) with optional filters. "
            "Returns case ID, title, status, severity, owner, label, and tags. "
            "Use this to get an overview of open investigations or find cases matching specific criteria."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filter by status: open, closed, resolved, new. Leave empty for all.",
                    "enum": ["open", "closed", "resolved", "new", ""],
                },
                "severity": {
                    "type": "string",
                    "description": "Filter by severity: high, medium, low, informational. Leave empty for all.",
                    "enum": ["high", "medium", "low", "informational", ""],
                },
                "label": {
                    "type": "string",
                    "description": "Filter by case label/type (e.g. phishing, malware, incident).",
                },
                "owner": {
                    "type": "string",
                    "description": "Filter by owner username.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of cases to return (default: 20, max: 50).",
                    "default": 20,
                },
            },
        },
    },
    "get_case": {
        "description": (
            "Get full details of a specific SOAR case by ID. "
            "Returns title, description, status, severity, owner, tags, artifacts count, "
            "notes count, playbook runs, and all custom fields. "
            "Use this after identifying a case with list_cases or search_cases."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The numeric SOAR container/case ID.",
                },
            },
            "required": ["case_id"],
        },
    },
    "search_cases": {
        "description": (
            "Search SOAR cases by keyword across title, description, and tags. "
            "Returns matching cases sorted by creation time (newest first). "
            "Useful for finding cases related to a specific threat, IOC, or incident."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search term to look for in case title and description.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default: 20).",
                    "default": 20,
                },
            },
            "required": ["query"],
        },
    },
    "list_artifacts": {
        "description": (
            "List all artifacts (IOCs, observables) associated with a SOAR case. "
            "Returns artifact ID, type, name, CEF fields (IP, domain, hash, URL, email, etc.), "
            "source, and creation time. "
            "Use this to see what indicators have been extracted or added to a case."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID to list artifacts for.",
                },
                "artifact_type": {
                    "type": "string",
                    "description": "Optional filter by CEF artifact type (e.g. ip, domain, hash, email, url).",
                },
            },
            "required": ["case_id"],
        },
    },
    "get_artifact": {
        "description": (
            "Get full details of a specific artifact by ID. "
            "Returns all CEF fields, tags, source, and associated case. "
            "Use this when you need the complete data for a specific IOC."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "artifact_id": {
                    "type": "integer",
                    "description": "The numeric SOAR artifact ID.",
                },
            },
            "required": ["artifact_id"],
        },
    },
    "list_case_notes": {
        "description": (
            "List all analyst notes and comments on a SOAR case. "
            "Returns note content, author, creation time. "
            "Use this to understand investigation history and analyst findings."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
            },
            "required": ["case_id"],
        },
    },
    "list_playbooks": {
        "description": (
            "List all available SOAR playbooks with name, description, category, and active status. "
            "Use this to discover what automated response or enrichment playbooks are available "
            "before recommending which one to run."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "category": {
                    "type": "string",
                    "description": "Optional filter by playbook category.",
                },
                "active_only": {
                    "type": "boolean",
                    "description": "Return only active playbooks (default: true).",
                    "default": True,
                },
            },
        },
    },
    "get_playbook_run": {
        "description": (
            "Get the status and results of a specific playbook run. "
            "Returns run status (running, success, failed), start/end time, "
            "action results, and any output data. "
            "Use this to check whether a playbook completed successfully."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {
                    "type": "integer",
                    "description": "The SOAR playbook run ID.",
                },
            },
            "required": ["run_id"],
        },
    },
    "list_action_runs": {
        "description": (
            "List recent action runs for a case, showing what automated actions have been executed, "
            "their status, app used, and results. "
            "Use this to understand what automated enrichment or response has already occurred."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of action runs to return (default: 20).",
                    "default": 20,
                },
            },
            "required": ["case_id"],
        },
    },
    "list_users": {
        "description": (
            "List SOAR users with username, display name, email, and role. "
            "Use this when suggesting case assignments or identifying available analysts."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "role": {
                    "type": "string",
                    "description": "Optional filter by role name.",
                },
            },
        },
    },
    "get_soar_info": {
        "description": (
            "Get system information about this SOAR instance: "
            "version, license info, connected apps count, and overall health status."
        ),
        "inputSchema": {"type": "object", "properties": {}},
    },
    # ── Write tools ──────────────────────────────────────────────────────────
    "add_case_note": {
        "description": (
            "⚠️ WRITE OPERATION — Add a note or comment to a SOAR case. "
            "The note will be visible to all analysts with access to the case. "
            "Review the note content carefully before confirming."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
                "note": {
                    "type": "string",
                    "description": "The note text to add (supports Markdown).",
                },
                "title": {
                    "type": "string",
                    "description": "Optional note title/subject.",
                },
            },
            "required": ["case_id", "note"],
        },
    },
    "run_playbook": {
        "description": (
            "⚠️ WRITE OPERATION — Run a SOAR playbook on a specific case. "
            "This triggers automated actions that may modify case state, send alerts, "
            "or take response actions. ALWAYS confirm with the analyst before calling this tool."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID to run the playbook on.",
                },
                "playbook_id": {
                    "type": "integer",
                    "description": "The SOAR playbook ID to run.",
                },
                "scope": {
                    "type": "string",
                    "description": "Scope for the playbook run: new or all (default: new).",
                    "enum": ["new", "all"],
                    "default": "new",
                },
            },
            "required": ["case_id", "playbook_id"],
        },
    },
    "update_case_status": {
        "description": (
            "⚠️ WRITE OPERATION — Update the status of a SOAR case. "
            "Valid statuses: open, closed, resolved, new."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
                "status": {
                    "type": "string",
                    "description": "New status value.",
                    "enum": ["open", "closed", "resolved", "new"],
                },
            },
            "required": ["case_id", "status"],
        },
    },
    "update_case_severity": {
        "description": (
            "⚠️ WRITE OPERATION — Update the severity of a SOAR case. "
            "Valid severities: high, medium, low, informational."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
                "severity": {
                    "type": "string",
                    "description": "New severity level.",
                    "enum": ["high", "medium", "low", "informational"],
                },
            },
            "required": ["case_id", "severity"],
        },
    },
    "update_case_owner": {
        "description": (
            "⚠️ WRITE OPERATION — Reassign a SOAR case to a different analyst."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
                "owner": {
                    "type": "string",
                    "description": "Username of the new owner/assignee.",
                },
            },
            "required": ["case_id", "owner"],
        },
    },
    "create_artifact": {
        "description": (
            "⚠️ WRITE OPERATION — Add a new artifact (IOC/observable) to a SOAR case. "
            "Provide at minimum the CEF field name and value (e.g. sourceAddress, fileHash)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "case_id": {
                    "type": "integer",
                    "description": "The SOAR container/case ID.",
                },
                "name": {
                    "type": "string",
                    "description": "Artifact name/label.",
                },
                "artifact_type": {
                    "type": "string",
                    "description": "CEF artifact type (e.g. ip, domain, hash, email, url, fileHash).",
                },
                "cef_data": {
                    "type": "object",
                    "description": "Key-value dict of CEF fields (e.g. {\"sourceAddress\": \"1.2.3.4\"}).",
                },
                "label": {
                    "type": "string",
                    "description": "Optional artifact label (default: artifact).",
                },
            },
            "required": ["case_id", "name", "artifact_type"],
        },
    },
    # ── Playbook-Discovery & Build tools (v1.6.0+) ────────────────────────────
    "list_apps": {
        "description": (
            "List installed SOAR apps/connectors. "
            "Returns app ID, name, publisher, product name, and supported action names. "
            "Use this to discover which connectors are available before building a playbook."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name_contains": {
                    "type": "string",
                    "description": "Optional substring filter applied client-side to app name or product name (case-insensitive).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default: 50).",
                    "default": 50,
                },
            },
        },
    },
    "list_assets": {
        "description": (
            "List configured SOAR assets (connector instances). "
            "Returns asset ID, name, linked app ID, product name, and configuration status. "
            "Actions are dispatched against assets (not apps) — use this after list_apps to "
            "find which asset to target in a playbook action block."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "app_id": {
                    "type": "integer",
                    "description": "Filter assets by app ID (from list_apps). Leave empty for all assets.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum number of results (default: 50).",
                    "default": 50,
                },
            },
        },
    },
    "get_action_schema": {
        "description": (
            "Get detailed input parameters and output datapaths for actions of a SOAR app. "
            "Returns for each action: parameter names, data types, required flag, contains tags, "
            "and output datapaths (e.g. action_result.summary.malicious). "
            "Use this after list_apps to understand what inputs an action needs and which datapath "
            "to reference in a playbook decision block."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "app_id": {
                    "type": "integer",
                    "description": "App ID from list_apps. At least one of app_id or action_name is required.",
                },
                "action_name": {
                    "type": "string",
                    "description": "Filter to actions matching this name substring (case-insensitive). If app_id is omitted, also used to search for the app.",
                },
            },
        },
    },
    "export_playbook": {
        "description": (
            "Export a SOAR playbook as a base64-encoded gzip TAR archive (.tgz). "
            "The archive contains the playbook's blockly graph, which is the structural "
            "ground-truth used by the Visual Playbook Editor (VPE) and the playbook-builder skill. "
            "Use a known-good playbook as a golden template before generating a new one."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "playbook_id": {
                    "type": "integer",
                    "description": "Numeric SOAR playbook ID (from list_playbooks).",
                },
            },
            "required": ["playbook_id"],
        },
    },
    "import_playbook": {
        "description": (
            "Import a playbook archive into SOAR so it appears and is editable in the "
            "Visual Playbook Editor (VPE). Accepts a base64-encoded gzip TAR archive "
            "(as returned by export_playbook). "
            "WRITE operation — disabled by default. Enable in asset config and mcp.conf."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "archive_b64": {
                    "type": "string",
                    "description": "Base64-encoded gzip TAR archive of the playbook (output of export_playbook or generated by skill).",
                },
                "scm": {
                    "type": "string",
                    "description": "Source Control Management repo name to import into (default: 'local').",
                    "default": "local",
                },
                "force": {
                    "type": "boolean",
                    "description": "Overwrite existing playbook with the same name (default: false).",
                    "default": False,
                },
            },
            "required": ["archive_b64"],
        },
    },
    "create_container": {
        "description": (
            "Create a labeled SOAR container (case) for isolated playbook self-testing. "
            "The container is tagged with the supplied label so it can be identified and "
            "cleaned up after testing. Never use this against real case queues. "
            "WRITE operation — disabled by default. Also requires enable_test_harness = true "
            "in [safety] of mcp.conf as an additional safety gate."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Container name (e.g. 'test_url_rep_2026-07-09').",
                },
                "label": {
                    "type": "string",
                    "description": "Container label/type (default: 'test'). Use a dedicated test label to keep test cases separate.",
                    "default": "test",
                },
                "severity": {
                    "type": "string",
                    "description": "Severity level (default: 'low').",
                    "enum": ["high", "medium", "low", "informational"],
                    "default": "low",
                },
            },
            "required": ["name"],
        },
    },
}


# ==============================================================================
# Tool implementations
# ==============================================================================


def tool_list_cases(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List SOAR cases with optional filters."""
    limit = min(int(args.get("limit") or 20), config.max_results)
    params: dict[str, Any] = {
        "_filter_status": f'"{args["status"]}"' if args.get("status") else None,
        "_filter_severity": f'"{args["severity"]}"' if args.get("severity") else None,
        "_filter_label": f'"{args["label"]}"' if args.get("label") else None,
        "_filter_owner_name": f'"{args["owner"]}"' if args.get("owner") else None,
        "page_size": limit,
        "sort": "create_time",
        "order": "desc",
    }
    params = {k: v for k, v in params.items() if v is not None}

    data, err = client.get("container", params=params)
    if err:
        return f"Error listing cases: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)

    # Apply min_severity filter if configured
    if config.min_severity:
        min_sev_val = _SEVERITY_ORDER.get(config.min_severity, 0)
        items = [c for c in items if _SEVERITY_ORDER.get(c.get("severity", "").lower(), 0) >= min_sev_val]

    # Apply allowed_labels filter if configured
    if config.allowed_labels:
        items = [c for c in items if c.get("label", "") in config.allowed_labels]

    if not items:
        return "No cases found matching the specified filters."

    suffix = f" (showing {len(items)} of {total} — use filters to narrow)" if total > limit else ""
    lines = [f"Found {len(items)} case(s){suffix}:\n"]
    for c in items[:limit]:
        lines.append(_fmt_case(c))
    result = "\n".join(lines)
    return result + (_disclaimer() if config.advisory_disclaimer else "")


def tool_get_case(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Get full details of a specific case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg

    data, err = client.get(f"container/{case_id}")
    if err:
        return f"Error fetching case {case_id}: {err}"
    if not isinstance(data, dict):
        return f"Unexpected response format for case {case_id}."

    # Fetch artifact count
    art_data, _ = client.get("artifact", params={"_filter_container_id": case_id, "page_size": 1})
    artifact_count = art_data.get("count", "unknown") if isinstance(art_data, dict) else "unknown"

    # Fetch note count
    note_data, _ = client.get("note", params={"_filter_container_id": case_id, "page_size": 1})
    note_count = note_data.get("count", "unknown") if isinstance(note_data, dict) else "unknown"

    tags = ", ".join(data.get("tags", []) or []) or "none"
    custom_fields = data.get("custom_fields") or {}

    # SOAR may use different field names for the modification timestamp (bug #8)
    updated = (
        data.get("modify_time")
        or data.get("update_time")
        or data.get("modified_time")
        or "unknown"
    )

    lines = [
        f"Case #{case_id}: {data.get('name', '(untitled)')}",
        f"  Status:      {data.get('status', 'unknown')}",
        f"  Severity:    {data.get('severity', 'unknown')}",
        f"  Owner:       {data.get('owner_name') or data.get('owner') or 'unassigned'}",
        f"  Label:       {data.get('label', 'none')}",
        f"  Tags:        {tags}",
        f"  Created:     {data.get('create_time', 'unknown')}",
        f"  Updated:     {updated}",
        f"  Artifacts:   {artifact_count}",
        f"  Notes:       {note_count}",
        f"  Description: {(data.get('description') or '(none)').strip()[:500]}",
    ]
    if custom_fields:
        lines.append("  Custom fields:")
        for k, v in list(custom_fields.items())[:10]:
            lines.append(f"    {k}: {v}")

    return "\n".join(lines) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_search_cases(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Search cases by keyword."""
    query = (args.get("query") or "").strip()
    if not query:
        return "Error: query is required."
    limit = min(int(args.get("limit") or 20), config.max_results)

    params = {
        "_filter_name__icontains": f'"{query}"',
        "page_size": limit,
        "sort": "create_time",
        "order": "desc",
    }
    data, err = client.get("container", params=params)
    if err:
        return f"Error searching cases: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)
    if not items:
        return f"No cases found matching '{query}'."

    suffix = f" (showing {len(items)} of {total} — refine query for more)" if total > limit else ""
    lines = [f"Found {len(items)} case(s) matching '{query}'{suffix}:\n"]
    for c in items[:limit]:
        lines.append(_fmt_case(c))
    return "\n".join(lines) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_list_artifacts(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List artifacts for a case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    art_type = args.get("artifact_type", "")
    limit = config.max_items_per_case

    params: dict = {
        "_filter_container_id": case_id,
        "page_size": limit,
    }
    if art_type:
        params["_filter_type__icontains"] = f'"{art_type}"'

    data, err = client.get("artifact", params=params)
    if err:
        return f"Error listing artifacts for case {case_id}: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)
    if not items:
        return f"No artifacts found for case {case_id}" + (f" of type '{art_type}'" if art_type else "") + "."

    suffix = f" (showing {len(items)} of {total} — use artifact_type to narrow)" if total > limit else ""
    lines = [f"Found {len(items)} artifact(s) for case #{case_id}{suffix}:\n"]
    for a in items:
        lines.append(_fmt_artifact(a))
    return "\n".join(lines) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_get_artifact(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Get full details of a specific artifact."""
    artifact_id, err_msg = _require_positive_int(args.get("artifact_id"), "artifact_id")
    if err_msg:
        return err_msg

    data, err = client.get(f"artifact/{artifact_id}")
    if err:
        return f"Error fetching artifact {artifact_id}: {err}"
    if not isinstance(data, dict):
        return f"Unexpected response for artifact {artifact_id}."

    cef = data.get("cef") or {}
    cef_lines = "\n".join(f"    {k}: {v}" for k, v in cef.items()) or "    (none)"
    tags = ", ".join(data.get("tags", []) or []) or "none"

    # SOAR returns the linked case as 'container' (not 'container_id') (bug #3)
    container = data.get("container") or data.get("container_id") or "unknown"

    return (
        f"Artifact #{artifact_id}: {data.get('name', '(unnamed)')}\n"
        f"  Type:    {data.get('type', 'unknown')}\n"
        f"  Case:    #{container}\n"
        f"  Source:  {data.get('source_data_identifier', 'unknown')}\n"
        f"  Tags:    {tags}\n"
        f"  Created: {data.get('create_time', 'unknown')}\n"
        f"  CEF fields:\n{cef_lines}"
    ) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_list_case_notes(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List analyst notes on a case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg

    data, err = client.get("note", params={"_filter_container_id": case_id, "page_size": config.max_items_per_case})
    if err:
        return f"Error listing notes for case {case_id}: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)
    if not items:
        return f"No notes found for case #{case_id}."

    count_label = f"{len(items)} of {total}" if total > len(items) else str(len(items))
    lines = [f"Notes for case #{case_id} ({count_label} total):\n"]
    for n in items:
        title = n.get("title") or n.get("note_title") or "(untitled)"
        # SOAR returns the author as a numeric user ID in the 'author' field (bug #6).
        # If author_name is absent, fall back gracefully with a user# prefix.
        author_raw = n.get("author_name") or n.get("author")
        if not author_raw:
            author = "(unknown)"
        elif isinstance(author_raw, int) or (
            isinstance(author_raw, str) and author_raw.isdigit()
        ):
            author = f"user#{author_raw}"
        else:
            author = str(author_raw)
        created = n.get("create_time") or n.get("modified_time") or "unknown"
        content = (n.get("content") or n.get("note") or "(empty)").strip()[:500]
        lines.append(f"  [{created}] {title} (by {author})")
        lines.append(f"    {content}")
        lines.append("")
    return "\n".join(lines)


def tool_list_playbooks(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List available SOAR playbooks."""
    active_only = args.get("active_only", True)
    category = args.get("category", "")

    params: dict = {"page_size": config.max_results}
    if active_only:
        params["_filter_active"] = "true"  # SOAR requires lowercase (bug #7)
    if category:
        params["_filter_category__icontains"] = f'"{category}"'

    data, err = client.get("playbook", params=params)
    if err:
        return f"Error listing playbooks: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)
    if not items:
        return "No playbooks found."

    count_label = f"{len(items)} of {total}" if total > len(items) else str(len(items))
    lines = [f"Available playbooks ({count_label}):\n"]
    for pb in items:
        status = "active" if pb.get("active") else "inactive"
        lines.append(
            f"  ID: {pb.get('id')} | {pb.get('name', '(unnamed)')} [{status}]\n"
            f"    Category: {pb.get('category', 'none')} | "
            f"Repo: {pb.get('scm', 'local')}\n"
            f"    Description: {(pb.get('description') or '(none)')[:200]}"
        )
    return "\n".join(lines)


def tool_get_playbook_run(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Get status and results of a playbook run."""
    run_id, err_msg = _require_positive_int(args.get("run_id"), "run_id")
    if err_msg:
        return err_msg

    data, err = client.get(f"playbook_run/{run_id}")
    if err:
        return f"Error fetching playbook run {run_id}: {err}"
    if not isinstance(data, dict):
        return f"Unexpected response for run {run_id}."

    status = data.get("status", "unknown")

    # Bug #4: SOAR returns 'playbook' as a flat integer (the playbook ID), not a
    # nested dict.  The human-readable name is embedded in the 'message' JSON blob.
    pb_name = str(data.get("playbook_id", "unknown"))
    try:
        msg_obj = json.loads(data.get("message", "{}") or "{}")
        pb_name = msg_obj.get("playbook") or msg_obj.get("name") or pb_name
    except (json.JSONDecodeError, TypeError):
        pass

    # Bug #4: start time may be 'start_time' or absent; fall back gracefully
    started = (
        data.get("start_time")
        or data.get("create_time")
        or "unknown"
    )

    return (
        f"Playbook Run #{run_id}\n"
        f"  Playbook:    {pb_name}\n"
        f"  Status:      {status}\n"
        f"  Case:        #{data.get('container', data.get('container_id', 'unknown'))}\n"
        f"  Started:     {started}\n"
        f"  Finished:    {data.get('update_time', data.get('end_time', 'still running'))}\n"
        f"  Message:     {data.get('message', '(none)')}"
    )


def tool_list_action_runs(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List action runs for a case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    limit = min(int(args.get("limit") or 20), config.max_results)

    data, err = client.get(
        "action_run",
        params={"_filter_container": case_id, "page_size": limit, "sort": "create_time", "order": "desc"},
    )
    if err:
        return f"Error listing action runs for case {case_id}: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)
    if not items:
        return f"No action runs found for case #{case_id}."

    count_label = f"{len(items)} of {total}" if total > len(items) else str(len(items))
    lines = [f"Action runs for case #{case_id} ({count_label} shown):\n"]
    for ar in items:
        # Bug #5: SOAR returns 'app' as a flat integer (app ID) not a nested dict.
        # Try 'app_name' first, then handle dict/string/int gracefully.
        app_field = ar.get("app")
        if isinstance(app_field, dict):
            app_name = app_field.get("name", "unknown")
        elif isinstance(app_field, str) and app_field:
            app_name = app_field
        else:
            app_name = ar.get("app_name") or (
                f"app#{app_field}" if isinstance(app_field, int) else "unknown"
            )
        lines.append(
            f"  [{ar.get('create_time', 'unknown')}] {ar.get('action', 'unknown')} "
            f"— {app_name} "
            f"— Status: {ar.get('status', 'unknown')}"
        )
    return "\n".join(lines)


def tool_list_users(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List SOAR users."""
    role = args.get("role", "")
    params: dict = {"page_size": config.max_results}
    if role:
        params["_filter_roles__name__icontains"] = f'"{role}"'

    data, err = client.get("ph_user", params=params)
    if err:
        return f"Error listing users: {err}"

    items = data if isinstance(data, list) else data.get("data", [])
    total = data.get("count", len(items)) if isinstance(data, dict) else len(items)
    if not items:
        return "No users found."

    count_label = f"{len(items)} of {total}" if total > len(items) else str(len(items))
    lines = [f"SOAR Users ({count_label}):\n"]
    for u in items:
        roles = ", ".join(r.get("name", "") if isinstance(r, dict) else str(r) for r in (u.get("roles") or []))
        lines.append(
            f"  {u.get('username', '(unknown)')} | {u.get('first_name', '')} {u.get('last_name', '')} "
            f"| {u.get('email', '')} | Roles: {roles or 'none'}"
        )
    return "\n".join(lines)


def tool_get_soar_info(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Get SOAR system info."""
    data, err = client.get("version")
    if err:
        return f"Error fetching SOAR version info: {err}"

    if not isinstance(data, dict):
        return "SOAR info received but in unexpected format."

    version = data.get("version", "unknown")
    build = data.get("build", "unknown")

    # Also fetch app count
    app_data, _ = client.get("app", params={"page_size": 1})
    app_count = app_data.get("count", "unknown") if isinstance(app_data, dict) else "unknown"

    # Fetch extended system info (requires admin token; gracefully ignore 403)
    license_line = ""
    sys_data, _ = client.get("system_info")
    if isinstance(sys_data, dict):
        license_status = sys_data.get("license_status", "")
        license_type = sys_data.get("license_type", "")
        if license_status:
            license_line = f"\n  License:  {license_status}" + (f" ({license_type})" if license_type else "")

    # Bug #2: endpoint URL was hardcoded with the wrong handler dir and asset name.
    # Read the persisted endpoint from config (written by the connector on first connect).
    mcp_ep = config.mcp_endpoint or f"{client._base_url}/rest/handler/<soarmcpserver_appid>/<asset_name>"

    return (
        f"Splunk SOAR Instance\n"
        f"  Version:  {version} (build {build}){license_line}\n"
        f"  Apps installed: {app_count}\n"
        f"  REST API: {client._base_url}/rest\n"
        f"  MCP Endpoint: {mcp_ep}"
    )


# ── Write tools ────────────────────────────────────────────────────────────────

def tool_add_case_note(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Add a note to a case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg

    note_text = (args.get("note") or "").strip()
    if not note_text:
        return "Error: note text is required."

    # Security fix #10: strip HTML tags to prevent stored XSS when the note is
    # rendered in the SOAR web UI (the CSP contains 'unsafe-inline' which would
    # allow injected <script> tags to execute in an analyst's browser).
    note_text = _HTML_TAG_RE.sub("", note_text)

    # Security fix #11: enforce a maximum note length to prevent storage exhaustion.
    if len(note_text) > _MAX_NOTE_LENGTH:
        return (
            f"Error: note exceeds maximum allowed length of {_MAX_NOTE_LENGTH} characters "
            f"({len(note_text)} chars supplied). Please shorten the note."
        )

    body = {
        "container_id": case_id,
        "content": note_text,
        "note_type": "general",
        "note_format": "markdown",
        "phase_id": 0,
        "title": (args.get("title") or "AI-Assisted Analysis Note").strip(),
    }
    data, err = client.post("note", body)
    if err:
        return f"Error adding note to case {case_id}: {err}"

    note_id = data.get("id", "unknown") if isinstance(data, dict) else "unknown"
    return (
        f"✅ Note added successfully to case #{case_id} (note ID: {note_id}).\n"
        f"Title: {body['title']}\n"
        f"Content: {note_text[:200]}{'...' if len(note_text) > 200 else ''}"
    ) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_run_playbook(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Run a playbook on a case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    playbook_id, err_msg = _require_positive_int(args.get("playbook_id"), "playbook_id")
    if err_msg:
        return err_msg

    scope = args.get("scope", "new")
    if scope not in ("new", "all"):
        scope = "new"

    body = {
        "container_id": case_id,
        "playbook_id": playbook_id,
        "scope": scope,
        "run": True,
    }
    data, err = client.post("playbook_run", body)
    if err:
        return f"Error running playbook {playbook_id} on case {case_id}: {err}"

    run_id = data.get("playbook_run_id", data.get("id", "unknown")) if isinstance(data, dict) else "unknown"
    return (
        f"✅ Playbook run started.\n"
        f"  Case: #{case_id} | Playbook: #{playbook_id} | Run ID: {run_id}\n"
        f"  Use get_playbook_run(run_id={run_id}) to check status."
    ) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_update_case_status(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Update case status."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    status = (args.get("status") or "").lower()
    if not status:
        return "Error: status is required."
    if status not in _VALID_STATUSES:
        return f"Error: Invalid status '{status}'. Valid: {', '.join(sorted(_VALID_STATUSES))}"

    data, err = client.post(f"container/{case_id}", {"status": status})
    if err:
        return f"Error updating status of case {case_id}: {err}"

    return f"✅ Case #{case_id} status updated to '{status}'." + (
        _disclaimer() if config.advisory_disclaimer else ""
    )


def tool_update_case_severity(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Update case severity."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    severity = (args.get("severity") or "").lower()
    if not severity:
        return "Error: severity is required."
    if severity not in _VALID_SEVERITIES:
        return f"Error: Invalid severity '{severity}'. Valid: {', '.join(sorted(_VALID_SEVERITIES))}"

    data, err = client.post(f"container/{case_id}", {"severity": severity})
    if err:
        return f"Error updating severity of case {case_id}: {err}"

    return f"✅ Case #{case_id} severity updated to '{severity}'." + (
        _disclaimer() if config.advisory_disclaimer else ""
    )


def tool_update_case_owner(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Update case owner."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    owner = (args.get("owner") or "").strip()
    if not owner:
        return "Error: owner is required."

    data, err = client.post(f"container/{case_id}", {"owner_name": owner})
    if err:
        return f"Error updating owner of case {case_id}: {err}"

    return f"✅ Case #{case_id} reassigned to '{owner}'." + (
        _disclaimer() if config.advisory_disclaimer else ""
    )


def tool_create_artifact(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Create a new artifact on a case."""
    case_id, err_msg = _require_positive_int(args.get("case_id"), "case_id")
    if err_msg:
        return err_msg
    name = (args.get("name") or "").strip()
    art_type = (args.get("artifact_type") or "").strip()
    cef_data = args.get("cef_data") or {}
    if not name or not art_type:
        return "Error: name and artifact_type are required."
    if not isinstance(cef_data, dict):
        cef_data = {}

    body = {
        "container_id": case_id,
        "name": name,
        "label": args.get("label", "artifact"),
        "type": art_type,
        "cef": cef_data,
        "source_data_identifier": f"mcp_created_{name}",
        "run_automation": bool(args.get("run_automation", False)),
    }
    data, err = client.post("artifact", body)
    if err:
        return f"Error creating artifact on case {case_id}: {err}"

    art_id = data.get("id", "unknown") if isinstance(data, dict) else "unknown"
    return (
        f"✅ Artifact created on case #{case_id} (artifact ID: {art_id}).\n"
        f"  Name: {name} | Type: {art_type}"
    ) + (_disclaimer() if config.advisory_disclaimer else "")


# ==============================================================================
# Playbook-Discovery & Build tool implementations (v1.6.0+)
# ==============================================================================


def tool_create_container(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Create an isolated test container for playbook self-testing."""
    # Double gate: tool enable flag (from asset config) AND safety flag in mcp.conf
    if not getattr(config, "enable_test_harness", False):
        return (
            "Error: create_container also requires enable_test_harness = true in the "
            "[safety] section of mcp.conf. This prevents accidental case creation in "
            "production SOAR instances. Set it to true only on test/dev instances."
        )

    name = (args.get("name") or "").strip()
    if not name:
        return "Error: name is required."

    label = (args.get("label") or "test").strip()
    severity = (args.get("severity") or "low").strip().lower()
    if severity not in _VALID_SEVERITIES:
        severity = "low"

    body = {
        "name": name,
        "label": label,
        "severity": severity,
        "status": "new",
    }

    data, err = client.post("container", body)
    if err:
        return f"Error creating container: {err}"

    if not isinstance(data, dict):
        return f"Container create response (raw): {data}"

    # VERIFY: response field 'id' on SOAR 8.5 (standard REST create response)
    container_id = data.get("id") or data.get("container_id") or "unknown"
    failed = data.get("failed", False)
    if failed:
        return f"Error: SOAR reported failed=true. Response: {data}"

    return (
        f"✅ Test container created.\n"
        f"  Container ID: {container_id}\n"
        f"  Name: {name}\n"
        f"  Label: {label} | Severity: {severity}"
    ) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_import_playbook(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Import a playbook archive into SOAR (POST /rest/import_playbook)."""
    import base64 as _b64

    archive_b64 = (args.get("archive_b64") or "").strip()
    if not archive_b64:
        return "Error: archive_b64 is required."

    try:
        _b64.b64decode(archive_b64, validate=True)
    except Exception:
        return "Error: archive_b64 is not valid base64."

    scm = (args.get("scm") or "local").strip()
    force = bool(args.get("force", False))

    # VERIFY: field name 'scm' vs 'scm_id' on SOAR 8.5.
    # The SOAR REST reference (Appendix A) uses 'scm'; 'scm_id' is an alias on some versions.
    body: dict = {
        "playbook": archive_b64,
        "scm": scm,
        "force": force,
    }

    data, err = client.post("import_playbook", body)
    if err:
        return f"Error importing playbook: {err}"

    if not isinstance(data, dict):
        return f"Import response (raw): {data}"

    # VERIFY: response field names on SOAR 8.5 — 'playbook_id' / 'id' / 'name' / 'status'
    pb_id = data.get("playbook_id") or data.get("id") or "unknown"
    name = data.get("playbook") or data.get("name") or "unknown"
    status = data.get("status") or data.get("message") or "imported"

    return (
        f"✅ Playbook imported successfully.\n"
        f"  Name: {name}\n"
        f"  ID: {pb_id}\n"
        f"  Status: {status}"
    ) + (_disclaimer() if config.advisory_disclaimer else "")


def tool_export_playbook(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Export a playbook as a base64-encoded gzip TAR archive."""
    import base64 as _b64

    pb_id, err_msg = _require_positive_int(args.get("playbook_id"), "playbook_id")
    if err_msg:
        return err_msg

    # VERIFY: GET /rest/playbook/{id}/export returns x-gzip binary on SOAR 8.5
    # (confirmed in SOAR REST reference for 8.x and Appendix A of the instruction)
    content, err = client.get_binary(f"playbook/{pb_id}/export")
    if err:
        return f"Error exporting playbook {pb_id}: {err}"

    if not content:
        return f"Error: empty response for playbook {pb_id} export."

    encoded = _b64.b64encode(content).decode("ascii")
    return (
        f"Playbook #{pb_id} exported ({len(content):,} bytes).\n"
        f"archive_b64: {encoded}"
    )


def tool_get_action_schema(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """Return input parameters and output datapaths for actions of a SOAR app."""
    app_id_raw = args.get("app_id")
    action_filter = (args.get("action_name") or "").strip().lower()

    if not app_id_raw and not action_filter:
        return "Error: at least one of app_id or action_name is required."

    app_name_hint = ""

    # If only action_name given, find the app via the /rest/app list
    if not app_id_raw and action_filter:
        all_data, _ = client.get("app", params={"page_size": 0})
        if isinstance(all_data, dict):
            for a in (all_data.get("data") or []):
                searchable = " ".join([
                    a.get("name") or "",
                    a.get("product_name") or "",
                    a.get("product_vendor") or "",
                ]).lower()
                if action_filter in searchable:
                    app_id_raw = a.get("id")
                    app_name_hint = a.get("name", "")
                    break
        if not app_id_raw:
            return (
                f"No app found matching '{action_filter}'. "
                f"Try list_apps to browse installed connectors, then call with app_id."
            )

    app_id, err_msg = _require_positive_int(app_id_raw, "app_id")
    if err_msg:
        return err_msg

    # Fetch the app name for display (lightweight call)
    if not app_name_hint:
        meta, _ = client.get(f"app/{app_id}")
        if isinstance(meta, dict):
            app_name_hint = meta.get("name", f"app_{app_id}")
        else:
            app_name_hint = f"app_{app_id}"

    # Action definitions live at /rest/app_action, not inside the app record.
    # The app record (/rest/app/{id}) only contains metadata (config, directory, etc.)
    data, err = client.get("app_action", params={"_filter_app": app_id, "page_size": 0})
    if err:
        return f"Error fetching actions for app {app_id} ({app_name_hint}): {err}"
    if not isinstance(data, dict):
        return f"Error: unexpected response type fetching actions for app {app_id}"

    actions = data.get("data") or []
    if not actions:
        return (
            f"App {app_id} ({app_name_hint}): no actions found at "
            f"/rest/app_action?_filter_app={app_id} (total count={data.get('count', 0)})."
        )

    if action_filter:
        actions = [
            a for a in actions
            if action_filter in (a.get("action") or "").lower()
            or action_filter in (a.get("identifier") or "").lower()
            or action_filter in (a.get("name") or "").lower()
        ]
    if not actions:
        return f"No action matching '{action_filter}' found in app {app_id} ({app_name_hint})."

    lines = [f"Action Schema — {app_name_hint} (app_id={app_id}):"]

    for action in actions[:20]:
        label = action.get("action") or action.get("name") or action.get("identifier") or "?"
        a_type = action.get("type", "unknown")
        read_only = action.get("read_only", "?")
        lines.append(f"\n  ── {label} (type={a_type}, read_only={read_only}) ──")

        # parameters: dict {name: {data_type, required, contains}} or list [{name, ...}]
        params_raw = action.get("parameters") or {}
        if isinstance(params_raw, dict):
            if params_raw:
                lines.append("    Parameters:")
                for p_name, p_info in params_raw.items():
                    if not isinstance(p_info, dict):
                        continue
                    req = "required" if p_info.get("required") else "optional"
                    dtype = p_info.get("data_type", "string")
                    contains = p_info.get("contains") or []
                    c_str = f"  [contains: {', '.join(contains)}]" if contains else ""
                    lines.append(f"      {p_name} ({dtype}, {req}){c_str}")
            else:
                lines.append("    Parameters: (none)")
        elif isinstance(params_raw, list):
            lines.append("    Parameters:")
            for p in params_raw:
                p_name = p.get("name") or p.get("data_item_name") or "?"
                req = "required" if p.get("required") else "optional"
                dtype = p.get("data_type", "string")
                contains = p.get("contains") or []
                c_str = f"  [contains: {', '.join(contains)}]" if contains else ""
                lines.append(f"      {p_name} ({dtype}, {req}){c_str}")

        outputs = action.get("output") or []
        if outputs:
            lines.append("    Output datapaths:")
            for o in outputs[:20]:
                dp = o.get("data_path", "?")
                dtype = o.get("data_type", "?")
                contains = o.get("contains") or []
                c_str = f"  [contains: {', '.join(contains)}]" if contains else ""
                lines.append(f"      {dp} ({dtype}){c_str}")
        else:
            lines.append("    Output datapaths: (none)")

    return "\n".join(lines)


def tool_list_assets(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List configured SOAR assets (connector instances)."""
    app_id_raw = args.get("app_id")
    limit = min(int(args.get("limit") or config.max_results), config.max_results)

    params: dict = {"page_size": 0}
    if app_id_raw is not None:
        app_id_val, err_msg = _require_positive_int(app_id_raw, "app_id")
        if err_msg:
            return err_msg
        # VERIFY: filter param name on SOAR 8.5 (_filter_app vs _filter_app_id)
        params["_filter_app"] = app_id_val

    data, err = client.get("asset", params=params)
    if err:
        return f"Error listing assets: {err}"

    assets = data.get("data", []) if isinstance(data, dict) else []
    total = data.get("count", len(assets)) if isinstance(data, dict) else len(assets)
    assets = assets[:limit]

    if not assets:
        return f"No assets found{' for app_id=' + str(app_id_raw) if app_id_raw else ''}."

    lines = [f"Configured SOAR Assets ({len(assets)} shown, {total} total):"]
    for a in assets:
        # VERIFY: 'app' field on 8.5 — may be int (app_id) or nested dict
        app_val = a.get("app")
        if isinstance(app_val, int):
            app_id_str = str(app_val)
        elif isinstance(app_val, dict):
            app_id_str = str(app_val.get("id", "?"))
        else:
            app_id_str = str(app_val) if app_val is not None else "unknown"

        # VERIFY: 'configuration_status' vs 'configured' boolean on 8.5
        cfg_status = a.get("configuration_status") or (
            "configured" if a.get("configured") else "not configured"
        )
        lines.append(
            f"\n  ID: {a.get('id')} | {a.get('name', '(unnamed)')}\n"
            f"    App ID: {app_id_str} | Product: {a.get('product_name', 'unknown')}\n"
            f"    Status: {cfg_status}"
        )
    return "\n".join(lines)


def tool_list_apps(client: SoarApiClient, config: McpServerConfig, args: dict) -> str:
    """List installed SOAR apps/connectors."""
    name_filter = (args.get("name_contains") or "").strip().lower()
    limit = min(int(args.get("limit") or config.max_results), config.max_results)

    data, err = client.get("app", params={"page_size": 0})
    if err:
        return f"Error listing apps: {err}"

    # VERIFY: 'data' array field name on SOAR 8.5 (expected from REST reference)
    apps = data.get("data", []) if isinstance(data, dict) else []
    total = data.get("count", len(apps)) if isinstance(data, dict) else len(apps)

    if name_filter:
        apps = [
            a for a in apps
            if name_filter in (a.get("name") or "").lower()
            or name_filter in (a.get("product_name") or "").lower()
        ]

    apps = apps[:limit]
    if not apps:
        return f"No apps found{' matching ' + repr(name_filter) if name_filter else ''}."

    lines = [f"Installed SOAR Apps ({len(apps)} shown, {total} total):"]
    for a in apps:
        # VERIFY: 'supported_actions' field name on SOAR 8.5
        supported = a.get("supported_actions") or []
        actions_str = (
            f"{len(supported)} action(s): {', '.join(supported[:5])}"
            + (" …" if len(supported) > 5 else "")
            if supported else "actions unknown (call get_action_schema)"
        )
        lines.append(
            f"\n  ID: {a.get('id')} | {a.get('name', '(unnamed)')}\n"
            f"    Vendor: {a.get('product_vendor') or a.get('publisher') or 'unknown'} | "
            f"Product: {a.get('product_name', 'unknown')}\n"
            f"    {actions_str}"
        )
    return "\n".join(lines)


# ==============================================================================
# Dispatcher
# ==============================================================================

_TOOL_HANDLERS = {
    "list_cases": tool_list_cases,
    "get_case": tool_get_case,
    "search_cases": tool_search_cases,
    "list_artifacts": tool_list_artifacts,
    "get_artifact": tool_get_artifact,
    "list_case_notes": tool_list_case_notes,
    "list_playbooks": tool_list_playbooks,
    "get_playbook_run": tool_get_playbook_run,
    "list_action_runs": tool_list_action_runs,
    "list_users": tool_list_users,
    "get_soar_info": tool_get_soar_info,
    # Write tools
    "add_case_note": tool_add_case_note,
    "run_playbook": tool_run_playbook,
    "update_case_status": tool_update_case_status,
    "update_case_severity": tool_update_case_severity,
    "update_case_owner": tool_update_case_owner,
    "create_artifact": tool_create_artifact,
    # Playbook-Discovery & Build tools (v1.6.0+)
    "list_apps": tool_list_apps,
    "list_assets": tool_list_assets,
    "get_action_schema": tool_get_action_schema,
    "export_playbook": tool_export_playbook,
    # Write tools (v1.6.0+)
    "import_playbook": tool_import_playbook,
    "create_container": tool_create_container,
}


def call_tool(
    tool_name: str,
    arguments: dict,
    client: SoarApiClient,
    config: McpServerConfig,
) -> str:
    """
    Dispatch a tool call to its implementation.

    Returns a text string as the MCP content response.
    Never raises; errors are returned as text.
    """
    handler = _TOOL_HANDLERS.get(tool_name)
    if handler is None:
        return f"Unknown tool: '{tool_name}'"
    try:
        result = handler(client, config, arguments or {})
        if config.log_tool_calls:
            logger.info("[MCP Tool] Called '%s' with args=%s", tool_name, list((arguments or {}).keys()))
        return result
    except Exception as exc:
        logger.exception("[MCP Tool] Unexpected error in tool '%s': %s", tool_name, exc)
        return f"Internal error executing tool '{tool_name}': {type(exc).__name__}"
